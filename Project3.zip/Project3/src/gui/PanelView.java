package gui;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import components.interact;

import javax.swing.JLabel;
import java.awt.Color;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JTextArea;
import javax.swing.JScrollPane;

public class PanelView extends JFrame {

	private JPanel contentPane;
	private JTextField txtGPR_0;
	private JTextField txtGPR_1;
	private JTextField txtGPR_2;
	private JTextField txtGPR_3;
	private JTextField txtIXR_1;
	private JTextField txtIXR_2;
	private JTextField txtIXR_3;
	private JTextField txtPC;
	private JTextField txtMAR;
	private JTextField txtMBR;
	private JTextField txtIR;
	private JTextField txtMFR;
	private JTextField txtPriv;
	private JTextField txtF;
	private JTextField txtF_1;
	private JTextField txtF_2;
	private JTextField txtF_3;
	private JTextField txtF_4;
	private JTextField txtF_5;
	private JTextField txtF_6;
	private JTextField txtF_7;
	private JTextField txtF_8;
	private JTextField txtF_9;
	private JTextField txtF_10;
	private JTextField txtF_11;
	private JTextField txtF_12;
	private JTextField txtF_13;
	private JTextField txtF_14;
	private JTextField txtF_15;
	private JTextField txt_halt;
	private JTextField txt_run;
	private JTextArea txt_area;
	private JTextField txtF_17;
	private JScrollPane scroll_pane;

	private interact cpu;		
	
	String OPBIT_0;
	String OPBIT_1;
	String OPBIT_2;
	String OPBIT_3;
	String OPBIT_4;
	String OPBIT_5;
	String GPR_BIT_1;
	String GPR_BIT_0;
	String IXR_BIT_1;
	String IXR_BIT_0;
	String i;
	String add4bit_IP;
	String add3bit_IP;
	String add2bit_IP;
	String add1bit_IP;
	String add0bit_IP;
	String INST, OPR, ADDR, GPR, IXR;
	
	private int PROGRAM_1_FLAG_1 = 1; 
	private int type_FLAG = 1;
	private JTextField txtF_16;
	private JTextField txtF_18;
	

	/**
	 * Main method to Launch the GUI
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					PanelView frame = new PanelView();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * All the components of Panel View 
	 */
	public PanelView() {
		//Set the main Frame
		setTitle("CSCI 6461 | Team 2");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 700, 800);
		contentPane = new JPanel();
		contentPane.setBackground(Color.GRAY);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		//GUI use cpu to interact with the CPU components
		cpu = new interact();
		
		
		//Labels
		JLabel lblGpr_0 = new JLabel("GPR 0");
		lblGpr_0.setBounds(20, 20, 41, 16);
		contentPane.add(lblGpr_0);
		
		JLabel lblGpr_1 = new JLabel("GPR 1");
		lblGpr_1.setBounds(20, 40, 41, 16);
		contentPane.add(lblGpr_1);
		
		JLabel lblGpr_2 = new JLabel("GPR 2");
		lblGpr_2.setBounds(20, 60, 41, 16);
		contentPane.add(lblGpr_2);
		
		JLabel lblGpr_3 = new JLabel("GPR 3");
		lblGpr_3.setBounds(20, 80, 41, 16);
		contentPane.add(lblGpr_3);
		
		JLabel lblIxr_1 = new JLabel("IXR 1");
		lblIxr_1.setBounds(20, 120, 41, 16);
		contentPane.add(lblIxr_1);
		
		JLabel lblIxr_2 = new JLabel("IXR 2");
		lblIxr_2.setBounds(20, 140, 41, 16);
		contentPane.add(lblIxr_2);
		
		JLabel lblIxr_3 = new JLabel("IXR 3");
		lblIxr_3.setBounds(20, 160, 41, 16);
		contentPane.add(lblIxr_3);
		
		//Text box to show data of GPR0  
		txtGPR_0 = new JTextField();
		
		//When a key is pressed by an user
		txtGPR_0.addKeyListener(new KeyAdapter() {
			@Override
			public void keyTyped(KeyEvent e) {
				char c = e.getKeyChar();
				if(!Character.isDigit(c)) {
					e.consume();
				}
			}
			//
			@Override
			public void keyPressed(KeyEvent e) {
				String input = txtGPR_0.getText();
				int length = input.length();
				char c = e.getKeyChar();
				if(e.getKeyChar()>= '0' && e.getKeyChar()<='1') {
					if(length<16) {
						txtGPR_0.setEditable(true);
					} else {
						txtGPR_0.setEditable(false);
					} 
				} else {
					if(e.getExtendedKeyCode()==KeyEvent.VK_BACK_SPACE || e.getExtendedKeyCode()==KeyEvent.VK_DELETE) {
						txtGPR_0.setEditable(true);
					} else {
						txtGPR_0.setEditable(false);
					}
					}
			}
		});
		txtGPR_0.setBounds(70, 20, 160, 16);
		contentPane.add(txtGPR_0);
		txtGPR_0.setColumns(10);
		
		//Text box to show data of GPR1
		txtGPR_1 = new JTextField();
		txtGPR_1.addKeyListener(new KeyAdapter() {
			@Override
			public void keyTyped(KeyEvent e) {
				char c = e.getKeyChar();
				if(!Character.isDigit(c)) {
					e.consume();
					}
				}
			@Override
			public void keyPressed(KeyEvent e) {
				String input = txtGPR_1.getText();
				int length = input.length();
				char c = e.getKeyChar();
				if(e.getKeyChar()>= '0' && e.getKeyChar()<='1') {
					if(length<16) {
						txtGPR_1.setEditable(true);
					} else {
						txtGPR_1.setEditable(false);
					} 
				} else {
					if(e.getExtendedKeyCode()==KeyEvent.VK_BACK_SPACE || e.getExtendedKeyCode()==KeyEvent.VK_DELETE) {
						txtGPR_1.setEditable(true);
					} else {
						txtGPR_1.setEditable(false);
					}
					}
			}
		});
		txtGPR_1.setColumns(10);
		txtGPR_1.setBounds(70, 40, 160, 16);
		contentPane.add(txtGPR_1);
		
		//Text box to show data of GPR2
		txtGPR_2 = new JTextField();
		txtGPR_2.addKeyListener(new KeyAdapter() {
			@Override
			public void keyTyped(KeyEvent e) {
				char c = e.getKeyChar();
				if(!Character.isDigit(c)) {
					e.consume();
					}
			}
			@Override
			public void keyPressed(KeyEvent e) {
				String input = txtGPR_2.getText();
				int length = input.length();
				char c = e.getKeyChar();
				if(e.getKeyChar()>= '0' && e.getKeyChar()<='1') {
					if(length<16) {
						txtGPR_2.setEditable(true);
					} else {
						txtGPR_2.setEditable(false);
					} 
				} else {
					if(e.getExtendedKeyCode()==KeyEvent.VK_BACK_SPACE || e.getExtendedKeyCode()==KeyEvent.VK_DELETE) {
						txtGPR_2.setEditable(true);
					} else {
						txtGPR_2.setEditable(false);
					}
					}
			}
		});
		txtGPR_2.setColumns(10);
		txtGPR_2.setBounds(70, 60, 160, 16);
		contentPane.add(txtGPR_2);
		
		//Text box to show data of GPR3
		txtGPR_3 = new JTextField();
		txtGPR_3.addKeyListener(new KeyAdapter() {
			@Override
			public void keyTyped(KeyEvent e) {
				char c = e.getKeyChar();
				if(!Character.isDigit(c)) {
					e.consume();
					}
			}
			@Override
			public void keyPressed(KeyEvent e) {
				String input = txtGPR_3.getText();
				int length = input.length();
				char c = e.getKeyChar();
				if(e.getKeyChar()>= '0' && e.getKeyChar()<='1') {
					if(length<16) {
						txtGPR_3.setEditable(true);
					} else {
						txtGPR_3.setEditable(false);
					} 
				} else {
					if(e.getExtendedKeyCode()==KeyEvent.VK_BACK_SPACE || e.getExtendedKeyCode()==KeyEvent.VK_DELETE) {
						txtGPR_3.setEditable(true);
					} else {
						txtGPR_3.setEditable(false);
					}
					}
			}
		});
		txtGPR_3.setColumns(10);
		txtGPR_3.setBounds(70, 80, 160, 16);
		contentPane.add(txtGPR_3);
		
		//Text box to show data of IXR1
		txtIXR_1 = new JTextField();
		txtIXR_1.addKeyListener(new KeyAdapter() {
			@Override
			public void keyTyped(KeyEvent e) {
				char c = e.getKeyChar();
				if(!Character.isDigit(c)) {
					e.consume();
					}
			}
			@Override
			public void keyPressed(KeyEvent e) {
				String input = txtIXR_1.getText();
				int length = input.length();
				char c = e.getKeyChar();
				if(e.getKeyChar()>= '0' && e.getKeyChar()<='1') {
					if(length<16) {
						txtIXR_1.setEditable(true);
					} else {
						txtIXR_1.setEditable(false);
					} 
				} else {
					if(e.getExtendedKeyCode()==KeyEvent.VK_BACK_SPACE || e.getExtendedKeyCode()==KeyEvent.VK_DELETE) {
						txtIXR_1.setEditable(true);
					} else {
						txtIXR_1.setEditable(false);
					}
					}
			}
		});
		txtIXR_1.setColumns(10);
		txtIXR_1.setBounds(70, 120, 160, 16);
		contentPane.add(txtIXR_1);
		
		//Text box to show data of IXR2
		txtIXR_2 = new JTextField();
		txtIXR_2.addKeyListener(new KeyAdapter() {
			@Override
			public void keyTyped(KeyEvent e) {
				char c = e.getKeyChar();
				if(!Character.isDigit(c)) {
					e.consume();
					}
			}
			@Override
			public void keyPressed(KeyEvent e) {
				String input = txtIXR_2.getText();
				int length = input.length();
				char c = e.getKeyChar();
				if(e.getKeyChar()>= '0' && e.getKeyChar()<='1') {
					if(length<16) {
						txtIXR_2.setEditable(true);
					} else {
						txtIXR_2.setEditable(false);
					} 
				} else {
					if(e.getExtendedKeyCode()==KeyEvent.VK_BACK_SPACE || e.getExtendedKeyCode()==KeyEvent.VK_DELETE) {
						txtIXR_2.setEditable(true);
					} else {
						txtIXR_2.setEditable(false);
					}
					}
			}
		});
		txtIXR_2.setColumns(10);
		txtIXR_2.setBounds(70, 140, 160, 16);
		contentPane.add(txtIXR_2);
		
		//Text box to show data of IXR3
		txtIXR_3 = new JTextField();
		txtIXR_3.addKeyListener(new KeyAdapter() {
			@Override
			public void keyTyped(KeyEvent e) {
				char c = e.getKeyChar();
				if(!Character.isDigit(c)) {
					e.consume();
					}
			}
			@Override
			public void keyPressed(KeyEvent e) {
				String input = txtIXR_3.getText();
				int length = input.length();
				char c = e.getKeyChar();
				if(e.getKeyChar()>= '0' && e.getKeyChar()<='1') {
					if(length<16) {
						txtIXR_3.setEditable(true);
					} else {
						txtIXR_3.setEditable(false);
					} 
				} else {
					if(e.getExtendedKeyCode()==KeyEvent.VK_BACK_SPACE || e.getExtendedKeyCode()==KeyEvent.VK_DELETE) {
						txtIXR_3.setEditable(true);
					} else {
						txtIXR_3.setEditable(false);
					}
					}
			}
		});
		txtIXR_3.setColumns(10);
		txtIXR_3.setBounds(70, 160, 160, 16);
		contentPane.add(txtIXR_3);
		
		//
		JButton btnGpr_0 = new JButton("LD");
		btnGpr_0.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				OPBIT_0 = txtF.getText();
				OPBIT_1 = txtF_1.getText();
				OPBIT_2 = txtF_2.getText();
				OPBIT_3 = txtF_3.getText();
				OPBIT_4 = txtF_4.getText();
				OPBIT_5 = txtF_5.getText();
				GPR_BIT_1 = txtF_6.getText();
				GPR_BIT_0 = txtF_7.getText();
				IXR_BIT_1 = txtF_8.getText();
				IXR_BIT_0 = txtF_9.getText();
				i = txtF_10.getText();
				add4bit_IP = txtF_11.getText();
				add3bit_IP = txtF_12.getText();
				add2bit_IP = txtF_13.getText();
				add1bit_IP = txtF_14.getText();
				add0bit_IP = txtF_15.getText();
				
				ADDR =  add4bit_IP + add3bit_IP + add2bit_IP + add1bit_IP + add0bit_IP;
				IXR = IXR_BIT_1 + IXR_BIT_0;
				GPR = GPR_BIT_1 + GPR_BIT_0;
				OPR = OPBIT_0 +  OPBIT_1 + OPBIT_2 + OPBIT_3 + OPBIT_4 + OPBIT_5;
				INST = OPR + GPR + IXR + i + ADDR;
				

				load_Gpr0();
			}
		});
		btnGpr_0.setBounds(240, 20, 50, 15);
		contentPane.add(btnGpr_0);
		
		//Load button of GPR1 is clicked
		JButton btnGpr_1 = new JButton("LD");
		btnGpr_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				OPBIT_0 = txtF.getText();
				OPBIT_1 = txtF_1.getText();
				OPBIT_2 = txtF_2.getText();
				OPBIT_3 = txtF_3.getText();
				OPBIT_4 = txtF_4.getText();
				OPBIT_5 = txtF_5.getText();
				GPR_BIT_1 = txtF_6.getText();
				GPR_BIT_0 = txtF_7.getText();
				IXR_BIT_1 = txtF_8.getText();
				IXR_BIT_0 = txtF_9.getText();
				i = txtF_10.getText();
				add4bit_IP = txtF_11.getText();
				add3bit_IP = txtF_12.getText();
				add2bit_IP = txtF_13.getText();
				add1bit_IP = txtF_14.getText();
				add0bit_IP = txtF_15.getText();
				
				ADDR =  add4bit_IP + add3bit_IP + add2bit_IP + add1bit_IP + add0bit_IP;
				IXR = IXR_BIT_1 + IXR_BIT_0;
				GPR = GPR_BIT_1 + GPR_BIT_0;
				OPR = OPBIT_0 +  OPBIT_1 + OPBIT_2 + OPBIT_3 + OPBIT_4 + OPBIT_5;
				INST = OPR + GPR + IXR + i + ADDR;
				
				load_Gpr1();
			}
		});
		btnGpr_1.setBounds(240, 40, 50, 15);
		contentPane.add(btnGpr_1);
		
		//Load button of GPR2 is clicked
		JButton btnGpr_2 = new JButton("LD");
		btnGpr_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				OPBIT_0 = txtF.getText();
				OPBIT_1 = txtF_1.getText();
				OPBIT_2 = txtF_2.getText();
				OPBIT_3 = txtF_3.getText();
				OPBIT_4 = txtF_4.getText();
				OPBIT_5 = txtF_5.getText();
				GPR_BIT_1 = txtF_6.getText();
				GPR_BIT_0 = txtF_7.getText();
				IXR_BIT_1 = txtF_8.getText();
				IXR_BIT_0 = txtF_9.getText();
				i = txtF_10.getText();
				add4bit_IP = txtF_11.getText();
				add3bit_IP = txtF_12.getText();
				add2bit_IP = txtF_13.getText();
				add1bit_IP = txtF_14.getText();
				add0bit_IP = txtF_15.getText();
				
				ADDR =  add4bit_IP + add3bit_IP + add2bit_IP + add1bit_IP + add0bit_IP;
				IXR = IXR_BIT_1 + IXR_BIT_0;
				GPR = GPR_BIT_1 + GPR_BIT_0;
				OPR = OPBIT_0 +  OPBIT_1 + OPBIT_2 + OPBIT_3 + OPBIT_4 + OPBIT_5;
				INST = OPR + GPR + IXR + i + ADDR;
				
				load_Gpr2();
			}
		});
		btnGpr_2.setBounds(240, 60, 50, 15);
		contentPane.add(btnGpr_2);
		
	    //Load button of GPR3 is clicked
		JButton btnGpr_3 = new JButton("LD");
		btnGpr_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				OPBIT_0 = txtF.getText();
				OPBIT_1 = txtF_1.getText();
				OPBIT_2 = txtF_2.getText();
				OPBIT_3 = txtF_3.getText();
				OPBIT_4 = txtF_4.getText();
				OPBIT_5 = txtF_5.getText();
				GPR_BIT_1 = txtF_6.getText();
				GPR_BIT_0 = txtF_7.getText();
				IXR_BIT_1 = txtF_8.getText();
				IXR_BIT_0 = txtF_9.getText();
				i = txtF_10.getText();
				add4bit_IP = txtF_11.getText();
				add3bit_IP = txtF_12.getText();
				add2bit_IP = txtF_13.getText();
				add1bit_IP = txtF_14.getText();
				add0bit_IP = txtF_15.getText();
				
				ADDR =  add4bit_IP + add3bit_IP + add2bit_IP + add1bit_IP + add0bit_IP;
				IXR = IXR_BIT_1 + IXR_BIT_0;
				GPR = GPR_BIT_1 + GPR_BIT_0;
				OPR = OPBIT_0 +  OPBIT_1 + OPBIT_2 + OPBIT_3 + OPBIT_4 + OPBIT_5;
				INST = OPR + GPR + IXR + i + ADDR;
				
				load_Gpr3();
			}
		});
		btnGpr_3.setBounds(240, 80, 50, 15);
		contentPane.add(btnGpr_3);
		
	    //Load button of IXR1 is clicked
		JButton btnIxr_1 = new JButton("LD");
		btnIxr_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				OPBIT_0 = txtF.getText();
				OPBIT_1 = txtF_1.getText();
				OPBIT_2 = txtF_2.getText();
				OPBIT_3 = txtF_3.getText();
				OPBIT_4 = txtF_4.getText();
				OPBIT_5 = txtF_5.getText();
				GPR_BIT_1 = txtF_6.getText();
				GPR_BIT_0 = txtF_7.getText();
				IXR_BIT_1 = txtF_8.getText();
				IXR_BIT_0 = txtF_9.getText();
				i = txtF_10.getText();
				add4bit_IP = txtF_11.getText();
				add3bit_IP = txtF_12.getText();
				add2bit_IP = txtF_13.getText();
				add1bit_IP = txtF_14.getText();
				add0bit_IP = txtF_15.getText();
				
				ADDR =  add4bit_IP + add3bit_IP + add2bit_IP + add1bit_IP + add0bit_IP;
				IXR = IXR_BIT_1 + IXR_BIT_0;
				GPR = GPR_BIT_1 + GPR_BIT_0;
				OPR = OPBIT_0 +  OPBIT_1 + OPBIT_2 + OPBIT_3 + OPBIT_4 + OPBIT_5;
				INST = OPR + GPR + IXR + i + ADDR;
				
				load_Ixr1();
			}
		});
		btnIxr_1.setBounds(240, 120, 50, 15);
		contentPane.add(btnIxr_1);
		
		//Load button of IXR2 is clicked
		JButton btnIxr_2 = new JButton("LD");
		btnIxr_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				OPBIT_0 = txtF.getText();
				OPBIT_1 = txtF_1.getText();
				OPBIT_2 = txtF_2.getText();
				OPBIT_3 = txtF_3.getText();
				OPBIT_4 = txtF_4.getText();
				OPBIT_5 = txtF_5.getText();
				GPR_BIT_1 = txtF_6.getText();
				GPR_BIT_0 = txtF_7.getText();
				IXR_BIT_1 = txtF_8.getText();
				IXR_BIT_0 = txtF_9.getText();
				i = txtF_10.getText();
				add4bit_IP = txtF_11.getText();
				add3bit_IP = txtF_12.getText();
				add2bit_IP = txtF_13.getText();
				add1bit_IP = txtF_14.getText();
				add0bit_IP = txtF_15.getText();
				
				ADDR =  add4bit_IP + add3bit_IP + add2bit_IP + add1bit_IP + add0bit_IP;
				IXR = IXR_BIT_1 + IXR_BIT_0;
				GPR = GPR_BIT_1 + GPR_BIT_0;
				OPR = OPBIT_0 +  OPBIT_1 + OPBIT_2 + OPBIT_3 + OPBIT_4 + OPBIT_5;
				INST = OPR + GPR + IXR + i + ADDR;
				
				load_Ixr2();
			}
		});
		btnIxr_2.setBounds(240, 140, 50, 15);
		contentPane.add(btnIxr_2);
		
		//Load button of IXR3 is clicked
		JButton btnIxr_3 = new JButton("LD");
		btnIxr_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				OPBIT_0 = txtF.getText();
				OPBIT_1 = txtF_1.getText();
				OPBIT_2 = txtF_2.getText();
				OPBIT_3 = txtF_3.getText();
				OPBIT_4 = txtF_4.getText();
				OPBIT_5 = txtF_5.getText();
				GPR_BIT_1 = txtF_6.getText();
				GPR_BIT_0 = txtF_7.getText();
				IXR_BIT_1 = txtF_8.getText();
				IXR_BIT_0 = txtF_9.getText();
				i = txtF_10.getText();
				add4bit_IP = txtF_11.getText();
				add3bit_IP = txtF_12.getText();
				add2bit_IP = txtF_13.getText();
				add1bit_IP = txtF_14.getText();
				add0bit_IP = txtF_15.getText();
				
				ADDR =  add4bit_IP + add3bit_IP + add2bit_IP + add1bit_IP + add0bit_IP;
				IXR = IXR_BIT_1 + IXR_BIT_0;
				GPR = GPR_BIT_1 + GPR_BIT_0;
				OPR = OPBIT_0 +  OPBIT_1 + OPBIT_2 + OPBIT_3 + OPBIT_4 + OPBIT_5;
				INST = OPR + GPR + IXR + i + ADDR;
				
				load_Ixr3();
			}
		});
		btnIxr_3.setBounds(240, 160, 50, 15);
		contentPane.add(btnIxr_3);
		
		//Labels
		JLabel lblPC = new JLabel("PC");
		lblPC.setBounds(335, 20, 25, 16);
		contentPane.add(lblPC);
		
		JLabel lblMAR = new JLabel("MAR");
		lblMAR.setBounds(335, 40, 30, 16);
		contentPane.add(lblMAR);
		
		JLabel lblMBR = new JLabel("MBR");
		lblMBR.setBounds(335, 61, 30, 15);
		contentPane.add(lblMBR);
		
		JLabel lblIR = new JLabel("IR");
		lblIR.setBounds(335, 80, 25, 16);
		contentPane.add(lblIR);
		
		JLabel lblMFR = new JLabel("MFR");
		lblMFR.setBounds(443, 101, 30, 16);
		contentPane.add(lblMFR);
		
		JLabel lblPriv = new JLabel("Privileged");
		lblPriv.setBounds(407, 120, 66, 16);
		contentPane.add(lblPriv);
		
		//Text box to show data of PC
		txtPC = new JTextField();	
		txtPC.setColumns(10);
		txtPC.setBounds(415, 20, 120, 16);
		contentPane.add(txtPC);
		
		//Text box to show data of MAR
		txtMAR = new JTextField();
		txtMAR.addKeyListener(new KeyAdapter() {
			@Override
			public void keyTyped(KeyEvent e) {
				char c = e.getKeyChar();
				if(!Character.isDigit(c)) {
					e.consume();
					}
			}
			@Override
			public void keyPressed(KeyEvent e) {
				String input = txtMAR.getText();
				int length = input.length();
				char c = e.getKeyChar();
				if(e.getKeyChar()>= '0' && e.getKeyChar()<='1') {
					if(length<12) {
						txtMAR.setEditable(true);
					} else {
						txtMAR.setEditable(false);
					} 
				} else {
					if(e.getExtendedKeyCode()==KeyEvent.VK_BACK_SPACE || e.getExtendedKeyCode()==KeyEvent.VK_DELETE) {
						txtMAR.setEditable(true);
					} else {
						txtMAR.setEditable(false);
					}
					}
			}
		});
		txtMAR.setColumns(10);
		txtMAR.setBounds(415, 40, 120, 16);
		contentPane.add(txtMAR);
		
		//Text box to show data of MBR
		txtMBR = new JTextField();
		txtMBR.addKeyListener(new KeyAdapter() {
			@Override
			public void keyTyped(KeyEvent e) {
				char c = e.getKeyChar();
				if(!Character.isDigit(c)) {
					e.consume();
					}
			}
			@Override
			public void keyPressed(KeyEvent e) {
				String input = txtMBR.getText();
				int length = input.length();
				char c = e.getKeyChar();
				if(e.getKeyChar()>= '0' && e.getKeyChar()<='1') {
					if(length<16) {
						txtMBR.setEditable(true);
					} else {
						txtMBR.setEditable(false);
					} 
				} else {
					if(e.getExtendedKeyCode()==KeyEvent.VK_BACK_SPACE || e.getExtendedKeyCode()==KeyEvent.VK_DELETE) {
						txtMBR.setEditable(true);
					} else {
						txtMBR.setEditable(false);
					}
					}
			}
		});
		txtMBR.setColumns(10);
		txtMBR.setBounds(377, 60, 160, 16);
		contentPane.add(txtMBR);
		
		//Text box to show data of IR
		txtIR = new JTextField();
		txtIR.addKeyListener(new KeyAdapter() {
			@Override
			public void keyTyped(KeyEvent e) {
				char c = e.getKeyChar();
				if(!Character.isDigit(c)) {
					e.consume();
					}
			}
		});
		txtIR.setColumns(10);
		txtIR.setBounds(375, 80, 160, 16);
		contentPane.add(txtIR);
		
		//Text box to show data of MFR
		txtMFR = new JTextField();
		txtMFR.addKeyListener(new KeyAdapter() {
			@Override
			public void keyTyped(KeyEvent e) {
				char c = e.getKeyChar();
				if(!Character.isDigit(c)) {
					e.consume();
					}
			}
		});
		txtMFR.setColumns(10);
		txtMFR.setBounds(485, 101, 50, 16);
		contentPane.add(txtMFR);
		
		//Text box to show data of Privileged
		txtPriv = new JTextField();
		txtPriv.addKeyListener(new KeyAdapter() {
			@Override
			public void keyTyped(KeyEvent e) {
				char c = e.getKeyChar();
				if(!Character.isDigit(c)) {
					e.consume();
					}
			}
		});
		txtPriv.setColumns(10);
		txtPriv.setBounds(515, 120, 20, 16);
		contentPane.add(txtPriv);
		
		//Load button of PC is clicked
		JButton btnPC = new JButton("LD");
		btnPC.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				OPBIT_0 = txtF.getText();
				OPBIT_1 = txtF_1.getText();
				OPBIT_2 = txtF_2.getText();
				OPBIT_3 = txtF_3.getText();
				OPBIT_4 = txtF_4.getText();
				OPBIT_5 = txtF_5.getText();
				GPR_BIT_1 = txtF_6.getText();
				GPR_BIT_0 = txtF_7.getText();
				IXR_BIT_1 = txtF_8.getText();
				IXR_BIT_0 = txtF_9.getText();
				i = txtF_10.getText();
				add4bit_IP = txtF_11.getText();
				add3bit_IP = txtF_12.getText();
				add2bit_IP = txtF_13.getText();
				add1bit_IP = txtF_14.getText();
				add0bit_IP = txtF_15.getText();
				
				ADDR =  add4bit_IP + add3bit_IP + add2bit_IP + add1bit_IP + add0bit_IP;
				IXR = IXR_BIT_1 + IXR_BIT_0;
				GPR = GPR_BIT_1 + GPR_BIT_0;
				OPR = OPBIT_0 +  OPBIT_1 + OPBIT_2 + OPBIT_3 + OPBIT_4 + OPBIT_5;
				INST = OPR + GPR + IXR + i + ADDR;
				
				load_PC();
			}
		});
		btnPC.setBounds(545, 20, 50, 15);
		contentPane.add(btnPC);
		
		//Load button of MAR is clicked
		JButton btnMAR = new JButton("LD");
		btnMAR.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				OPBIT_0 = txtF.getText();
				OPBIT_1 = txtF_1.getText();
				OPBIT_2 = txtF_2.getText();
				OPBIT_3 = txtF_3.getText();
				OPBIT_4 = txtF_4.getText();
				OPBIT_5 = txtF_5.getText();
				GPR_BIT_1 = txtF_6.getText();
				GPR_BIT_0 = txtF_7.getText();
				IXR_BIT_1 = txtF_8.getText();
				IXR_BIT_0 = txtF_9.getText();
				i = txtF_10.getText();
				add4bit_IP = txtF_11.getText();
				add3bit_IP = txtF_12.getText();
				add2bit_IP = txtF_13.getText();
				add1bit_IP = txtF_14.getText();
				add0bit_IP = txtF_15.getText();
				
				ADDR =  add4bit_IP + add3bit_IP + add2bit_IP + add1bit_IP + add0bit_IP;
				IXR = IXR_BIT_1 + IXR_BIT_0;
				GPR = GPR_BIT_1 + GPR_BIT_0;
				OPR = OPBIT_0 +  OPBIT_1 + OPBIT_2 + OPBIT_3 + OPBIT_4 + OPBIT_5;
				INST = OPR + GPR + IXR + i + ADDR;
				
				load_MAR();
			}
		});
		btnMAR.setBounds(545, 40, 50, 15);
		contentPane.add(btnMAR);
		
		//Load button of MBR is clicked
		JButton btnMBR = new JButton("LD");
		btnMBR.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				OPBIT_0 = txtF.getText();
				OPBIT_1 = txtF_1.getText();
				OPBIT_2 = txtF_2.getText();
				OPBIT_3 = txtF_3.getText();
				OPBIT_4 = txtF_4.getText();
				OPBIT_5 = txtF_5.getText();
				GPR_BIT_1 = txtF_6.getText();
				GPR_BIT_0 = txtF_7.getText();
				IXR_BIT_1 = txtF_8.getText();
				IXR_BIT_0 = txtF_9.getText();
				i = txtF_10.getText();
				add4bit_IP = txtF_11.getText();
				add3bit_IP = txtF_12.getText();
				add2bit_IP = txtF_13.getText();
				add1bit_IP = txtF_14.getText();
				add0bit_IP = txtF_15.getText();
				
				ADDR =  add4bit_IP + add3bit_IP + add2bit_IP + add1bit_IP + add0bit_IP;
				IXR = IXR_BIT_1 + IXR_BIT_0;
				GPR = GPR_BIT_1 + GPR_BIT_0;
				OPR = OPBIT_0 +  OPBIT_1 + OPBIT_2 + OPBIT_3 + OPBIT_4 + OPBIT_5;
				INST = OPR + GPR + IXR + i + ADDR;
				
				load_MBR();
			}
		});
		btnMBR.setBounds(545, 60, 50, 15);
		contentPane.add(btnMBR);
		
		
		//Buttons for INST 0-15
		//User cannot click these buttons for now. 
				
		//Labels of Operation, GPR, IXR, I, Address
		JLabel lblNewLabel = new JLabel("Operation");
		lblNewLabel.setBounds(79, 250, 66, 16);
		contentPane.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("GPR");
		lblNewLabel_1.setBounds(235, 250, 30, 16);
		contentPane.add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("IXR");
		lblNewLabel_2.setBounds(310, 250, 25, 16);
		contentPane.add(lblNewLabel_2);
		
		JLabel lblNewLabel_3 = new JLabel("I");
		lblNewLabel_3.setBounds(380, 250, 9, 16);
		contentPane.add(lblNewLabel_3);
		
		JLabel lblNewLabel_4 = new JLabel("Address");
		lblNewLabel_4.setBounds(460, 250, 65, 16);
		contentPane.add(lblNewLabel_4);
		
		//Load button is clicked
		JButton btnLoad = new JButton("Load");
		btnLoad.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				OPBIT_0 = txtF.getText();
				OPBIT_1 = txtF_1.getText();
				OPBIT_2 = txtF_2.getText();
				OPBIT_3 = txtF_3.getText();
				OPBIT_4 = txtF_4.getText();
				OPBIT_5 = txtF_5.getText();
				GPR_BIT_1 = txtF_6.getText();
				GPR_BIT_0 = txtF_7.getText();
				IXR_BIT_1 = txtF_8.getText();
				IXR_BIT_0 = txtF_9.getText();
				i = txtF_10.getText();
				add4bit_IP = txtF_11.getText();
				add3bit_IP = txtF_12.getText();
				add2bit_IP = txtF_13.getText();
				add1bit_IP = txtF_14.getText();
				add0bit_IP = txtF_15.getText();
				
				ADDR =  add4bit_IP + add3bit_IP + add2bit_IP + add1bit_IP + add0bit_IP;
				IXR = IXR_BIT_1 + IXR_BIT_0;
				GPR = GPR_BIT_1 + GPR_BIT_0;
				OPR = OPBIT_0 +  OPBIT_1 + OPBIT_2 + OPBIT_3 + OPBIT_4 + OPBIT_5;
				INST = OPR + GPR + IXR + i + ADDR;
				
				load();
				
				
			}
		});
		btnLoad.setBounds(377, 320, 75, 30);
		contentPane.add(btnLoad);
		
		//Store button is clicked
		JButton btnStore = new JButton("Store");
		btnStore.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				OPBIT_0 = txtF.getText();
				OPBIT_1 = txtF_1.getText();
				OPBIT_2 = txtF_2.getText();
				OPBIT_3 = txtF_3.getText();
				OPBIT_4 = txtF_4.getText();
				OPBIT_5 = txtF_5.getText();
				GPR_BIT_1 = txtF_6.getText();
				GPR_BIT_0 = txtF_7.getText();
				IXR_BIT_1 = txtF_8.getText();
				IXR_BIT_0 = txtF_9.getText();
				i = txtF_10.getText();
				add4bit_IP = txtF_11.getText();
				add3bit_IP = txtF_12.getText();
				add2bit_IP = txtF_13.getText();
				add1bit_IP = txtF_14.getText();
				add0bit_IP = txtF_15.getText();
				
				ADDR =  add4bit_IP + add3bit_IP + add2bit_IP + add1bit_IP + add0bit_IP;
				IXR = IXR_BIT_1 + IXR_BIT_0;
				GPR = GPR_BIT_1 + GPR_BIT_0;
				OPR = OPBIT_0 +  OPBIT_1 + OPBIT_2 + OPBIT_3 + OPBIT_4 + OPBIT_5;
				INST = OPR + GPR + IXR + i + ADDR;
				
				store();
			}
		});
		btnStore.setBounds(377, 365, 75, 30);
		contentPane.add(btnStore);
		
		//IPL button clicked
		JButton btnNewButton_6 = new JButton("IPL");
		btnNewButton_6.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				IPL();
			}
		});
		btnNewButton_6.setBounds(470, 320, 65, 30);
		contentPane.add(btnNewButton_6);
		
		//SS button clicked
		JButton btnNewButton_7 = new JButton("SS");
		btnNewButton_7.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				SS(0);
			}
		});
		btnNewButton_7.setBounds(310, 320, 50, 45);
		contentPane.add(btnNewButton_7);
		
		//Text box of OPR bit0
		txtF = new JTextField();
		txtF.addKeyListener(new KeyAdapter() {
			@Override
			public void keyPressed(KeyEvent e) {
				String input = txtF.getText();
				int length = input.length();
				char c = e.getKeyChar();
				if(e.getKeyChar()>= '0' && e.getKeyChar()<='1') {
					if(length<1) {
						txtF.setEditable(true);
					} else {
						txtF.setEditable(false);
					} 
				} else {
					if(e.getExtendedKeyCode()==KeyEvent.VK_BACK_SPACE || e.getExtendedKeyCode()==KeyEvent.VK_DELETE) {
						txtF.setEditable(true);
					} else {
						txtF.setEditable(false);
					}
					}
			}
		});
		txtF.setBounds(22, 215, 25, 26);
		contentPane.add(txtF);
		txtF.setColumns(10);
		
		
		//Text box of OPR bit1
		txtF_1 = new JTextField();
		txtF_1.addKeyListener(new KeyAdapter() {
			@Override
			public void keyPressed(KeyEvent e) {
				String input = txtF_1.getText();
				int length = input.length();
				char c = e.getKeyChar();
				if(e.getKeyChar()>= '0' && e.getKeyChar()<='1') {
					if(length<1) {
						txtF_1.setEditable(true);
					} else {
						txtF_1.setEditable(false);
					} 
				} else {
					if(e.getExtendedKeyCode()==KeyEvent.VK_BACK_SPACE || e.getExtendedKeyCode()==KeyEvent.VK_DELETE) {
						txtF_1.setEditable(true);
					} else {
						txtF_1.setEditable(false);
					}
					}
			}
		});
		txtF_1.setColumns(10);
		txtF_1.setBounds(52, 215, 25, 26);
		contentPane.add(txtF_1);
		
		//Text box of OPR bit2
		txtF_2 = new JTextField();
		txtF_2.addKeyListener(new KeyAdapter() {
			@Override
			public void keyPressed(KeyEvent e) {
				String input = txtF_2.getText();
				int length = input.length();
				char c = e.getKeyChar();
				if(e.getKeyChar()>= '0' && e.getKeyChar()<='1') {
					if(length<1) {
						txtF_2.setEditable(true);
					} else {
						txtF_2.setEditable(false);
					} 
				} else {
					if(e.getExtendedKeyCode()==KeyEvent.VK_BACK_SPACE || e.getExtendedKeyCode()==KeyEvent.VK_DELETE) {
						txtF_2.setEditable(true);
					} else {
						txtF_2.setEditable(false);
					}
					}
			}
		});
		txtF_2.setColumns(10);
		txtF_2.setBounds(82, 215, 25, 26);
		contentPane.add(txtF_2);
		
		//Text box of OPR bit3
		txtF_3 = new JTextField();
		txtF_3.addKeyListener(new KeyAdapter() {
			@Override
			public void keyPressed(KeyEvent e) {
				String input = txtF_3.getText();
				int length = input.length();
				char c = e.getKeyChar();
				if(e.getKeyChar()>= '0' && e.getKeyChar()<='1') {
					if(length<1) {
						txtF_3.setEditable(true);
					} else {
						txtF_3.setEditable(false);
					} 
				} else {
					if(e.getExtendedKeyCode()==KeyEvent.VK_BACK_SPACE || e.getExtendedKeyCode()==KeyEvent.VK_DELETE) {
						txtF_3.setEditable(true);
					} else {
						txtF_3.setEditable(false);
					}
					}
			}
		});
		txtF_3.setColumns(10);
		txtF_3.setBounds(112, 215, 25, 26);
		contentPane.add(txtF_3);
		
		//Text box of OPR bit4
		txtF_4 = new JTextField();
		txtF_4.addKeyListener(new KeyAdapter() {
			@Override
			public void keyPressed(KeyEvent e) {
				String input = txtF_4.getText();
				int length = input.length();
				char c = e.getKeyChar();
				if(e.getKeyChar()>= '0' && e.getKeyChar()<='1') {
					if(length<1) {
						txtF_4.setEditable(true);
					} else {
						txtF_4.setEditable(false);
					} 
				} else {
					if(e.getExtendedKeyCode()==KeyEvent.VK_BACK_SPACE || e.getExtendedKeyCode()==KeyEvent.VK_DELETE) {
						txtF_4.setEditable(true);
					} else {
						txtF_4.setEditable(false);
					}
					}
			}
		});
		txtF_4.setColumns(10);
		txtF_4.setBounds(142, 215, 25, 26);
		contentPane.add(txtF_4);

		
		//Text box of OPR bit5
		txtF_5 = new JTextField();
		txtF_5.addKeyListener(new KeyAdapter() {
			@Override
			public void keyPressed(KeyEvent e) {
				String input = txtF_5.getText();
				int length = input.length();
				char c = e.getKeyChar();
				if(e.getKeyChar()>= '0' && e.getKeyChar()<='1') {
					if(length<1) {
						txtF_5.setEditable(true);
					} else {
						txtF_5.setEditable(false);
					} 
				} else {
					if(e.getExtendedKeyCode()==KeyEvent.VK_BACK_SPACE || e.getExtendedKeyCode()==KeyEvent.VK_DELETE) {
						txtF_5.setEditable(true);
					} else {
						txtF_5.setEditable(false);
					}
					}
			}
		});
		txtF_5.setColumns(10);
		txtF_5.setBounds(172, 215, 25, 26);
		contentPane.add(txtF_5);
		
		//Text box of GPR bit1
		txtF_6 = new JTextField();
		txtF_6.addKeyListener(new KeyAdapter() {
		@Override
		public void keyPressed(KeyEvent e) {
			String input = txtF_6.getText();
			int length = input.length();
			char c = e.getKeyChar();
			if(e.getKeyChar()>= '0' && e.getKeyChar()<='1') {
				if(length<1) {
					txtF_6.setEditable(true);
				} else {
					txtF_6.setEditable(false);
				} 
			} else {
				if(e.getExtendedKeyCode()==KeyEvent.VK_BACK_SPACE || e.getExtendedKeyCode()==KeyEvent.VK_DELETE) {
					txtF_6.setEditable(true);
				} else {
					txtF_6.setEditable(false);
				}
				}
		}
	});
		txtF_6.setColumns(10);
		txtF_6.setBounds(218, 215, 25, 26);
		contentPane.add(txtF_6);
		
		//Text box of GPR bit0
		txtF_7 = new JTextField();
		txtF_7.addKeyListener(new KeyAdapter() {
			@Override
			public void keyPressed(KeyEvent e) {
				String input = txtF_7.getText();
				int length = input.length();
				char c = e.getKeyChar();
				if(e.getKeyChar()>= '0' && e.getKeyChar()<='1') {
					if(length<1) {
						txtF_7.setEditable(true);
					} else {
						txtF_7.setEditable(false);
					} 
				} else {
					if(e.getExtendedKeyCode()==KeyEvent.VK_BACK_SPACE || e.getExtendedKeyCode()==KeyEvent.VK_DELETE) {
						txtF_7.setEditable(true);
					} else {
						txtF_7.setEditable(false);
					}
					}
			}
		});
		txtF_7.setColumns(10);
		txtF_7.setBounds(248, 215, 25, 26);
		contentPane.add(txtF_7);
		
		//Text box of IXR bit1
		txtF_8 = new JTextField();
		txtF_8.addKeyListener(new KeyAdapter() {
			@Override
			public void keyPressed(KeyEvent e) {
				String input = txtF_8.getText();
				int length = input.length();
				char c = e.getKeyChar();
				if(e.getKeyChar()>= '0' && e.getKeyChar()<='1') {
					if(length<1) {
						txtF_8.setEditable(true);
					} else {
						txtF_8.setEditable(false);
					} 
				} else {
					if(e.getExtendedKeyCode()==KeyEvent.VK_BACK_SPACE || e.getExtendedKeyCode()==KeyEvent.VK_DELETE) {
						txtF_8.setEditable(true);
					} else {
						txtF_8.setEditable(false);
					}
					}
			}
		});
		txtF_8.setColumns(10);
		txtF_8.setBounds(292, 215, 25, 26);
		contentPane.add(txtF_8);
		
		//Text box of IXR bit0
		txtF_9 = new JTextField();
		txtF_9.addKeyListener(new KeyAdapter() {
			@Override
			public void keyPressed(KeyEvent e) {
				String input = txtF_9.getText();
				int length = input.length();
				char c = e.getKeyChar();
				if(e.getKeyChar()>= '0' && e.getKeyChar()<='1') {
					if(length<1) {
						txtF_9.setEditable(true);
					} else {
						txtF_9.setEditable(false);
					} 
				} else {
					if(e.getExtendedKeyCode()==KeyEvent.VK_BACK_SPACE || e.getExtendedKeyCode()==KeyEvent.VK_DELETE) {
						txtF_9.setEditable(true);
					} else {
						txtF_9.setEditable(false);
					}
					}
			}
		});
		txtF_9.setColumns(10);
		txtF_9.setBounds(322, 215, 25, 26);
		contentPane.add(txtF_9);
		
		//Text box of I
		txtF_10 = new JTextField();
		txtF_10.addKeyListener(new KeyAdapter() {
			@Override
			public void keyPressed(KeyEvent e) {
				String input = txtF_10.getText();
				int length = input.length();
				char c = e.getKeyChar();
				if(e.getKeyChar()>= '0' && e.getKeyChar()<='1') {
					if(length<1) {
						txtF_10.setEditable(true);
					} else {
						txtF_10.setEditable(false);
					} 
				} else {
					if(e.getExtendedKeyCode()==KeyEvent.VK_BACK_SPACE || e.getExtendedKeyCode()==KeyEvent.VK_DELETE) {
						txtF_10.setEditable(true);
					} else {
						txtF_10.setEditable(false);
					}
					}
			}
		});
		txtF_10.setColumns(10);
		txtF_10.setBounds(367, 215, 25, 26);
		contentPane.add(txtF_10);
		
		//Text box of ADDR bit4
		txtF_11 = new JTextField();
		txtF_11.addKeyListener(new KeyAdapter() {
			@Override
			public void keyPressed(KeyEvent e) {
				String input = txtF_11.getText();
				int length = input.length();
				char c = e.getKeyChar();
				if(e.getKeyChar()>= '0' && e.getKeyChar()<='1') {
					if(length<1) {
						txtF_11.setEditable(true);
					} else {
						txtF_11.setEditable(false);
					} 
				} else {
					if(e.getExtendedKeyCode()==KeyEvent.VK_BACK_SPACE || e.getExtendedKeyCode()==KeyEvent.VK_DELETE) {
						txtF_11.setEditable(true);
					} else {
						txtF_11.setEditable(false);
					}
					}
			}
		});
		txtF_11.setColumns(10);
		txtF_11.setBounds(412, 215, 25, 26);
		contentPane.add(txtF_11);
		
		//Text box of ADDR bit3
		txtF_12 = new JTextField();
		txtF_12.addKeyListener(new KeyAdapter() {
			@Override
			public void keyPressed(KeyEvent e) {
				String input = txtF_12.getText();
				int length = input.length();
				char c = e.getKeyChar();
				if(e.getKeyChar()>= '0' && e.getKeyChar()<='1') {
					if(length<1) {
						txtF_12.setEditable(true);
					} else {
						txtF_12.setEditable(false);
					} 
				} else {
					if(e.getExtendedKeyCode()==KeyEvent.VK_BACK_SPACE || e.getExtendedKeyCode()==KeyEvent.VK_DELETE) {
						txtF_12.setEditable(true);
					} else {
						txtF_12.setEditable(false);
					}
					}
			}
		});
		txtF_12.setColumns(10);
		txtF_12.setBounds(442, 215, 25, 26);
		contentPane.add(txtF_12);
		
		//Text box of ADDR bit2
		txtF_13 = new JTextField();
		txtF_13.addKeyListener(new KeyAdapter() {
			@Override
			public void keyPressed(KeyEvent e) {
				String input = txtF_13.getText();
				int length = input.length();
				char c = e.getKeyChar();
				if(e.getKeyChar()>= '0' && e.getKeyChar()<='1') {
					if(length<1) {
						txtF_13.setEditable(true);
					} else {
						txtF_13.setEditable(false);
					} 
				} else {
					if(e.getExtendedKeyCode()==KeyEvent.VK_BACK_SPACE || e.getExtendedKeyCode()==KeyEvent.VK_DELETE) {
						txtF_13.setEditable(true);
					} else {
						txtF_13.setEditable(false);
					}
					}
			}
		});
		txtF_13.setColumns(10);
		txtF_13.setBounds(472, 215, 25, 26);
		contentPane.add(txtF_13);
		
		//Text box of ADDR bit1
		txtF_14 = new JTextField();
		txtF_14.addKeyListener(new KeyAdapter() {
			@Override
			public void keyPressed(KeyEvent e) {
				String input = txtF_14.getText();
				int length = input.length();
				char c = e.getKeyChar();
				if(e.getKeyChar()>= '0' && e.getKeyChar()<='1') {
					if(length<1) {
						txtF_14.setEditable(true);
					} else {
						txtF_14.setEditable(false);
					} 
				} else {
					if(e.getExtendedKeyCode()==KeyEvent.VK_BACK_SPACE || e.getExtendedKeyCode()==KeyEvent.VK_DELETE) {
						txtF_14.setEditable(true);
					} else {
						txtF_14.setEditable(false);
					}
					}
			}
		});
		txtF_14.setColumns(10);
		txtF_14.setBounds(502, 215, 25, 26);
		contentPane.add(txtF_14);
		
		//Text box of ADDR bit0
		txtF_15 = new JTextField();
		txtF_15.addKeyListener(new KeyAdapter() {
			@Override
			public void keyPressed(KeyEvent e) {
				String input = txtF_15.getText();
				int length = input.length();
				char c = e.getKeyChar();
				if(e.getKeyChar()>= '0' && e.getKeyChar()<='1') {
					if(length<1) {
						txtF_15.setEditable(true);
					} else {
						txtF_15.setEditable(false);
					} 
				} else {
					if(e.getExtendedKeyCode()==KeyEvent.VK_BACK_SPACE || e.getExtendedKeyCode()==KeyEvent.VK_DELETE) {
						txtF_15.setEditable(true);
					} else {
						txtF_15.setEditable(false);
					}
					}
			}
		});
		txtF_15.setColumns(10);
		txtF_15.setBounds(532, 215, 25, 26);
		contentPane.add(txtF_15);
		
		//Labels of Halt and Run
		JLabel lblNewLabel_5 = new JLabel("Halt");
		lblNewLabel_5.setBounds(210, 325, 30, 16);
		contentPane.add(lblNewLabel_5);
		
		JLabel lblNewLabel_6 = new JLabel("Run");
		lblNewLabel_6.setBounds(210, 354, 35, 16);
		contentPane.add(lblNewLabel_6);
		
		//Shows if the program is halted
		txt_halt = new JTextField();
		txt_halt.setBackground(Color.WHITE);
		txt_halt.setBounds(245, 320, 25, 26);
		contentPane.add(txt_halt);
		txt_halt.setColumns(10);
		
		//Shows if the program is still running
		txt_run = new JTextField();
		txt_run.setColumns(10);
		txt_run.setBackground(Color.GREEN);
		txt_run.setBounds(245, 349, 25, 26);
		contentPane.add(txt_run);
		
		JButton btnNewButton_8 = new JButton("LOAD Program-1");
		btnNewButton_8.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				loadProgram1();
			}
		});
		btnNewButton_8.setBounds(20, 340, 140, 29);
		contentPane.add(btnNewButton_8);
		
		JButton btnNewButton_9 = new JButton("Input");
		btnNewButton_9.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String data = txtF_17.getText();
				input(data);
			}
		});
		btnNewButton_9.setBounds(30, 390, 117, 29);
		contentPane.add(btnNewButton_9);
		
		JLabel lbl_input = new JLabel("Input:");
		lbl_input.setBounds(30, 430, 117, 29);
		contentPane.add(lbl_input);
		
		JButton btnNewButton_10 = new JButton("Get output");
		btnNewButton_10.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				runProgram1ToTheEnd();
			}
		});
		btnNewButton_10.setBounds(240, 426, 117, 29);
		contentPane.add(btnNewButton_10);
		
		JButton btnNewButton_11 = new JButton("Run single INST");
		btnNewButton_11.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				SS(1);
			}
		});
		btnNewButton_11.setBounds(377, 426, 171, 29);
		contentPane.add(btnNewButton_11);
		
		txtF_17 = new JTextField();
		txtF_17.setBounds(70, 430, 117, 29);
		contentPane.add(txtF_17);
		txtF_17.setColumns(10);
		
		txt_area = new JTextArea();
		txt_area.setEditable (false);
        txt_area.setLineWrap(true);
        txt_area.setWrapStyleWord(true);
        scroll_pane = new JScrollPane(txt_area);
        scroll_pane.setBounds(32, 470, 516, 200);
		contentPane.add(scroll_pane);
		
		JLabel lblNewLabel_7 = new JLabel("Keyboard");
		lblNewLabel_7.setBounds(335, 160, 61, 16);
		contentPane.add(lblNewLabel_7);
		
		JLabel lblNewLabel_8 = new JLabel("Printer");
		lblNewLabel_8.setBounds(335, 185, 61, 16);
		contentPane.add(lblNewLabel_8);
		
		txtF_16 = new JTextField();
		txtF_16.setBounds(407, 155, 130, 26);
		contentPane.add(txtF_16);
		txtF_16.setColumns(10);
		
		txtF_18 = new JTextField();
		txtF_18.setBounds(407, 180, 130, 26);
		contentPane.add(txtF_18);
		txtF_18.setColumns(10);
	}
	
	// Current status of CPU and displays it after each click
	public void display() {
		txtGPR_0.setText(Integer.toBinaryString(cpu.get_number(1)));
        txtGPR_1.setText(Integer.toBinaryString(cpu.get_number(2)));
        txtGPR_2.setText(Integer.toBinaryString(cpu.get_number(3)));
        txtGPR_3.setText(Integer.toBinaryString(cpu.get_number(4)));
        txtIXR_1.setText(Integer.toBinaryString(cpu.get_number(5)));
        txtIXR_2.setText(Integer.toBinaryString(cpu.get_number(6)));
        txtIXR_3.setText(Integer.toBinaryString(cpu.get_number(7)));
        txtPC.setText(Integer.toBinaryString(cpu.get_number(8)));
        txtMAR.setText(Integer.toBinaryString(cpu.get_number(9)));
        txtMBR.setText(Integer.toBinaryString(cpu.get_number(10)));
        txtIR.setText(Integer.toBinaryString(cpu.get_number(11)));
        txtMFR.setText(Integer.toBinaryString(cpu.get_number(12)));
        txtF_16.setText(Integer.toString(cpu.get_number(13)));
        txtF_18.setText(Integer.toString(cpu.get_number(14)));
	}
	
	//Give the CPU the input of load INST, execute it, and see if anything went wrong. If something went wrong, stop.
	public void load() {
        int halt = cpu.Load_button(INST);
        display();
        if (halt == 1) {
        	txt_halt.setBackground(Color.RED);
        	txt_run.setBackground(Color.WHITE);
        }
	}
	
	// Provide the CPU the store INST input, execute it, and determine whether anything went wrong or not. If something went wrong, stop.

	public void store() {
        int halt = cpu.Store_button(INST);
        display();
        if (halt == 1) {
        	txt_halt.setBackground(Color.RED);
        	txt_run.setBackground(Color.WHITE);
        }
	}
	
	// Call the CPU's initial function to restart the machine.

	public void IPL() {
		cpu.IPL_button();
		display();
        txt_halt.setBackground(Color.WHITE);
       	txt_run.setBackground(Color.GREEN);
	}
	
	// invoke the run single-step function, which will carry out every step of carrying out a command.

	public void SS(int flag) {
		if (PROGRAM_1_FLAG_1 == 2) {
			txt_area.setText(txt_area.getText() + "\nThe 20 numbers are:\n");
			for (int i = 0; i < 20; i++) {
				txt_area.setText(txt_area.getText() + cpu.pro1_20numbers(i) + " ");
			}
			System.out.println(cpu.CPU.device.printer);
			txt_area.setText(txt_area.getText() + "\nThe closest number to " + cpu.pro1target() + " is in device-1 printer, which is " + cpu.printer() + "\n");
			return;
		}
		int halt = cpu.SS_button();
		display();
		if (halt == 1) {
        	txt_halt.setBackground(Color.RED);
        	txt_run.setBackground(Color.WHITE);
        }
		if (flag == 1) {
			txt_area.setText(txt_area.getText() + "execute the instruction " + Integer.toBinaryString(cpu.get_number(11)) + ", then the PC is " + cpu.get_number(8) + "\n");
			if (cpu.get_number(11) == 0) {
				PROGRAM_1_FLAG_1 = 2;
			}
		}
	}
	
	//  Gpr0
	public void load_Gpr0() {
		cpu.LD_button(INST, 1);
		display();
	}
	
	// Load to Gpr1
	public void load_Gpr1() {
		cpu.LD_button(INST, 2);
		display();
	}
	
	// Load to Gpr2
	public void load_Gpr2() {
		cpu.LD_button(INST, 3);
		display();
	}
	
	// Load to Gpr3
	public void load_Gpr3() {
		cpu.LD_button(INST, 4);
		display();
	}
	
	// Load to Ixr1
	public void load_Ixr1() {
		cpu.LD_button(INST, 5);
		display();
	}
	
	// Load to Ixr2
	public void load_Ixr2() {
		cpu.LD_button(INST, 6);
		display();
	}
	
	// Load to Ixr3
	public void load_Ixr3() {
		cpu.LD_button(INST, 7);
		display();
	}
	
	// Load to PC
	public void load_PC() {
		cpu.LD_button(INST, 8);
		display();
	}
	
	// Load to MAR
	public void load_MAR() {
		cpu.LD_button(INST, 9);
		display();
	}
	
	// Load to MBR
	public void load_MBR() {
		cpu.LD_button(INST, 10);
		display();
	}
	
	// Insert the data to the memory and limit the number between 0-65535
	public void input(String data) {
		if (PROGRAM_1_FLAG_1 == 2) { 
			return;
		}
		int number = Integer.parseInt(data);
		if (number < 0) {
			txt_area.setText(txt_area.getText() + "The number should be Non-negtive, kindly write again\n");
			return;
		}
		else if (number > 65535) {
			txt_area.setText(txt_area.getText() + "The number should be below 65536, kindly write again\n");
			return;
		}
		
		if (PROGRAM_1_FLAG_1 == 0) {	
			cpu.program1input(data);
			SS(1);
			SS(1);
			txt_area.setText(txt_area.getText() + "get compare number:" + data + "\nplease click the button Run single INST \nOr click button Get output to get the result directly" +"\n");
			return;
		}
		
		int next = cpu.program1input(data);	
		for (int i = 0; i < 7; i++) {
			SS(1);
		}
		if (next == 1) {
			txt_area.setText(txt_area.getText() + "getnumber:" + data + "\n\n");
		}
		else {
			txt_area.setText(txt_area.getText() + "getnumber:" + data + "\n\n");
			txt_area.setText(txt_area.getText() + "\nNow the memory has 20 numbers which are:\n");
			for (int i = 0; i < 20; i++) {
				txt_area.setText(txt_area.getText() + cpu.pro1_20numbers(i) + " ");
			}
			txt_area.setText(txt_area.getText() + "\nPlease enter another number to compare and click on Input Button to get the closest number\n\n");
			PROGRAM_1_FLAG_1 = 0;
		}
	}
	

	public void loadProgram1() {
		PROGRAM_1_FLAG_1 = 1;
		cpu.loadprogram1();
		txt_area.setText("Now the program1 has been loaded to the memory.\nPlease write 20 numbers in the textfield above the input button and press input button for each number\n then write the last number to compare and get the closest number from the 20 numbers\n\n");
		display();
        txt_halt.setBackground(Color.WHITE);
       	txt_run.setBackground(Color.GREEN);
       	SS(1);
	}
	
	// This function will finish running program 1 and print the result.

	public void runProgram1ToTheEnd() {
		if (PROGRAM_1_FLAG_1 == 1) {
			return;
		}
		do {
			SS(1);
		} while (PROGRAM_1_FLAG_1 != 2);
		SS(1);
	}
}
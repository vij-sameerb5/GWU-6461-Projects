package components;

public class Program_counter {
	//Initialization of PC to 0
	private int PCaddress = 0;

	public Program_counter(){
	}

	//Initialize the PC address if correct
	public Program_counter(int PCaddress){
		if (PCaddress < Math.pow(2,12) && PCaddress >= 0){
			this.PCaddress = PCaddress;
		}
	}

	//Increments PC
	public void PCPlus(){
		PCaddress++;
	}

	//Gets PC address
	public int getPCaddress(){
		return PCaddress;
	}

	//fits the machine's range and reassigns the PC address if necessary.
	public boolean setPCaddress(int newaddress){
		if (newaddress < Math.pow(2,12) && newaddress >= 0){
			PCaddress = newaddress;
			return true;
		}
		else
			return false;
	}
}

package components;

public class MBR{
	//Initialization of MBR
	private int Data = 0;

	public MBR(){
	}

	//Gets data in the MBR
	public int getData(){
		return Data;
	}

	public boolean setData(int newData){
		//Condition to check if the data is appropriate before assigning it to the MBR
		if (newData < Math.pow(2,16) && newData >= 0){
			Data = newData;
			return true;
		}
		else
			return false;
	}
}
package components;

public class Device {
	public int keyboard = 0;
	public int printer = 0;
}

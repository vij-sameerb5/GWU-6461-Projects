package components;

// Compute un-signed number
public class ALU {
	private int Q = 0; 
	private int S = 0; 
	public ConditionCode CC = new ConditionCode();
	
	public boolean setY(int first_data){
		
		CC.resetCC();
		S = 0;
		//Condition to check if the data is appropriate prior setting it to the register
		if (first_data < Math.pow(2,16) && first_data >= 0){
			Q = first_data;
			return true;
		}
		else
			return false;
	}
	
	public void add(int second_data){
		S = Q + second_data;
		if (S >= Math.pow(2,16)) {
			CC.OVERFLOW();
		}
	}
	
	public void subtract(int second_data){
		S = Q - second_data;
		if (S < 0) {
			CC.UNDERFLOW();
		}
	}
	
	public void multiply(int second_data) {
		S = Q * second_data;
		if (S >= Math.pow(2,16)) {
			CC.OVERFLOW();
		}
	}
	
	public void divide(int second_data) {
		if (second_data == 0) {
			CC.DIVZERO();
		}
		else {
			S = Q / second_data;
		}
	}
	
	public void equal(int second_data) {
		if (Q == second_data) {
			CC.EQUALORNOT();
		}
	}
	
	public void and(int second_data) {
		S = Q & second_data;
	}
	
	public void or(int second_data) {
		S = Q | second_data;
	}
	
	public void not(int second_data) {
		S = 0;
		for (int i = 15; i >= 0; i--) {
			S += Math.pow(((second_data / (int) Math.pow(2, i)) + 1 ) % 2 * 2, i);
			second_data %= (int) Math.pow(2, i);
		}
	}
	
	public void remainder(int second_data) {
		if (second_data == 0) {
			CC.DIVZERO();
		}
		else {
			S = Q % second_data;
		}
	}
	
	public void shift(int second_data, int AL, int LR, int count) {
		if (AL == 0) {
			if (LR == 1) {
				short signed = (short) second_data;
				S = (int) (signed << count); 
			}
			else if (LR == 0) {
				short signed = (short) second_data;
				S = (int) (signed >> count); 
			}
		}
		else if (AL == 1) {
			if (LR == 1) {
				S = second_data * (int) Math.pow(2, count);
				short lowbits = (short) S;
				S = (int) lowbits;
			}
			else if (LR == 0) {
				short signed = (short) second_data;
				S = (int) (signed >>> count); 
			}
		}
	}
	
	public void rotate(int second_data, int LR, int count) {
		if (LR == 1) {
			S = second_data * (int) Math.pow(2, count);
			int highbits = S / (int) Math.pow(2, 16);
			short lowbits = (short) S;
			S = (int) lowbits;
			S += highbits;
		}
		else if (LR == 0) {
			int lowbits = second_data % (int) Math.pow(2, count);
			short signed = (short) second_data;
			S = (int) (signed >>> count); 
			S += lowbits * (int) Math.pow(2, 16 - count);
		}
	}
	
	public int getResult() {
		return S;
	}
}

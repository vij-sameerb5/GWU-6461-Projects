package components;

//Write-through cache
public class Cache extends Memory {
	private int[] flags = new int[16];	
	private int[] cnts = new int[16];	
	private int[] tags = new int[16];	
	private int[][] data = new int [16][8];
	
	public Cache() {
		super(2048, 8);
	}
	
	public int readCache(int address) {
		// For dealing with machine fault
		if (address < start && address >= 0) {
			return -1;
		}
		else if (address > Memwords.length) {
			return -2;
		}
		
		int tag = address / 8;
		int readline = matchTag(tag);
		// The target block is not in cache if it is -1
		if (readline == -1) {
			 readline = FIFO(tag);
		}
		int wordAddress = address % 8;
		return data[readline][wordAddress];
	}
	
	public int writeCache(int address, int newData) {
		// For dealing with machine fault
		if (address < start && address >= 0) {
			return -1;
		}
		else if (address > Memwords.length) {
			return -2;
		}
		
		int tag = address / 8;
		int writeline = matchTag(tag);
		// The target block is not in cache if it is -1
		if (writeline == -1) {
			 writeline = FIFO(tag);
		}
		int wordAddress = address % 8;
		data[writeline][wordAddress] = newData;
		
		
		for (int i = 0; i < 8; i++) {
			writeMem(tag * 8 + i, data[writeline][i]);
		}
		return 0;
	}
	
	// Locate the target line; return -1 if the target block is not currently cached.
	private int matchTag(int tag) {
		for (int i = 0; i < 16; i++) {
			if (flags[i] == 1) {
				if (tags[i] == tag) {
					return i;
				}
			}
		}
		return -1;
	}
	
	
	private int FIFO(int tag) {
		
		int replaceLine = -1;
		for (int i = 0; i < 16; i++) {
			if (flags[i] == 0) {
				replaceLine = i;
				flags[i] = 1;
			}
		}
		if (replaceLine == -1) {
			int maxCnt = 0;
			for (int i = 0; i < 16; i++) {
				if (cnts[i] > maxCnt) {
					maxCnt = cnts[i];
					replaceLine = i;
				}
			}
		}
		
		
		for (int i = 0; i < 8; i++) {
			data[replaceLine][i] = readMem(tag * 8 + i);
		}
		tags[replaceLine] = tag;
		for (int i = 0; i < 16; i++) {
			if (flags[i] == 1) {
				cnts[i]++;
			}
		}
		return replaceLine;
	}
}

package components;

public class MAR{
	//Initialization of MAR
	private int Memaddress = 0;

	public MAR(){
	}
	
	//Gets current address in the MAR
	public int getMemaddress(){
		return Memaddress;
	}

	//Obtains the updated address, assesses whether it is suitable, and then sets 
	public boolean setMemaddress(int newaddress){
		if (newaddress < Math.pow(2,12) && newaddress >= 0){
			Memaddress = newaddress;
			return true;
		}
		else
			return false;
	}
}
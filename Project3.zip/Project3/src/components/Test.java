package components;

public class Test {
	public static void main(String args[]) {
		CPU Test = new CPU();
		Test.initial();
		Test.load_program1();
		
		// test our own straightforward IPL of four instructions

//		for (int i = 0; i < 4; i++) {
//			System.out.println("PC:" + Test.PC.getPCaddress());
//			Test.runsinglestep();
//		}
		
		
//		System.out.println(Test.Mem.readMem(100));
//		System.out.println(Test.Mem.readMem(101));
//		
//		System.out.println(Test.GPRs.getregister(0));
//		System.out.println(Test.GPRs.getregister(1));
//		
//		System.out.println(Test.Mem.readMem(1000));
//		System.out.println(Test.Mem.readMem(1001));
		
		
		//Test.Mem.writeMem(7, 0b0000010001000000);
		//Test.runsinglestep();
		//System.out.println(Test.GPRs.getregister(0));
		
		
		//Test.Mem.writeMem(8, 0b0000100110000000);
		//Test.GPRs.setregister(1, 10);
		//Test.runsinglestep();
		//System.out.println(Test.Mem.readMem(100));
	}
}

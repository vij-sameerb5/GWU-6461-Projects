package components;


// ID	Fault
// 0	Unauthorized Memory Address to Reserved Spaces Set MFR to 0001 binary.
// 1	MFR for the illegal TRAP code is binary 0010.
// 2	MFR for Illegal Operation set to 0100
// 3	Unauthorized Memory Address (with installed memory) greater than 2048  MFR is configured to 1000 binary.


public class MFR {
	private int Faultindex = -1;
	
	public MFR() {
	}
	
	public int getFault() {
		return Faultindex;
	}
	
	public boolean setFault(int Faultindex) {
		if (Faultindex >= 0 && Faultindex < 4) {
			this.Faultindex = Faultindex;
			return true;
		}
		else 
			return false;
	}
	
	public void resetMFR() {
		Faultindex = 0;
	}
}

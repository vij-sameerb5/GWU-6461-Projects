package components;

public class Memory{
	// Initial conditions for the memory
	protected int[] Memwords = new int[2048];
	protected int start = 0;

	protected Memory(){
	}

	protected Memory(int size, int start){
		if (size >= 2048 && size <= 4096){
			Memwords = new int[size];
		}
		if (start >= 0 && start < size){
			this.start = start;
		}
	}

	protected int readMem(int address){
		if (address >= start && address < Memwords.length)
			return Memwords[address];
		else if (address < start && address >= 0) {
			return -1;
		}
		else if (address > Memwords.length) {
			return -2;
		}
		else
			return -3;
	}
	
	protected int CPUaccess(int address) {
		return Memwords[address];
	}

	protected int writeMem(int address, int newData){
		if (address >= start && address < Memwords.length){
			if (newData >= 0 && newData < Math.pow(2, 16)){
				Memwords[address] = newData;
				return 0;
			}
			else
				return 1;
		}
		else if (address < start && address >= 0) {
			return -1;
		}
		else if (address > Memwords.length) {
			return -2;
		}
		else
			return -3;
	}
	
	//	Utilized by CPU_control to get entry to the designated area

	protected void CPUwrite(int address, int newData) {
		Memwords[address] = newData;
	}
}
package components;

public class IndexRegister{
	//Initialization of the index registers
	private int[] registers = {0, 0, 0};

	public IndexRegister(){
	}

	public IndexRegister(int register1, int register2, int register3){
		// Recreate the IXR, choose the appropriate register, and set a value limit.
		if (register1 < Math.pow(2, 12) && register1 >= 0)
			registers[0] = register1;
		if (register2 < Math.pow(2, 12) && register2 >= 0)
			registers[1] = register2;
		if (register3 < Math.pow(2, 12) && register3 >= 0)
			registers[2] = register3;
	}

	public int getregister(int index){
		if (index >= 1 && index < 4)
			return registers[index - 1];
		else
			return -1;
	}
	
	public boolean setregister(int index, int newvalue) {

		if (index >= 1 && index < 4) {
			if (newvalue < Math.pow(2, 12) && newvalue >= 0) {
				registers[index - 1] = newvalue;
				return true;
			}
			else
				return false;
		}
		else
			return false;
	}
}
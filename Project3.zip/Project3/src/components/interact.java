package components;

// The GUI can utilize this class, and the object CPU has all of its components.

import conversion.ConvertBinToDec;

public class interact {
	public CPU CPU = new CPU();
	public int pro1inputcnt = 0; // Count for 20 numbers input to program-1
	
	public interact() {
		CPU.initial();
	}
	
	public void IPL_button() {
		CPU.initial();
	}
	
	public int SS_button() {
		CPU.runsinglestep();
		return CPU.halt;	// return halt or not; if halt is 1, an error occurred, and the MFR display will be altered.
	}
	
	
	public int Load_button(String InputofBin) {
		int Input = ConvertBinToDec.convertbintodec(InputofBin);
		CPU.IR.setinstruction(Input);
		CPU.runinstruction();
		return CPU.halt;	// return halt or not, if halt is 1, it indicates an issue and the MFR display will alter.
	}
	
	// if opcode is correct that is 000010
	public int Store_button(String InputofBin) {
		int Input = ConvertBinToDec.convertbintodec(InputofBin);
		CPU.IR.setinstruction(Input);
		CPU.runinstruction();
		return CPU.halt;	// return halt or not, if halt is 1, it indicates an issue and the MFR display will alter.
	}
	
	// LD_button has the ability to alter each component's value based on the GUI's order.
	public boolean LD_button(String InputofBin, int index) {
		int Input = ConvertBinToDec.convertbintodec(InputofBin);
		switch (index) {
		case 1:
			return CPU.GPRs.setregister(0, Input);
		case 2:
			return CPU.GPRs.setregister(1, Input);
		case 3:
			return CPU.GPRs.setregister(2, Input);
		case 4:
			return CPU.GPRs.setregister(3, Input);
		case 5:
			return CPU.IXR.setregister(1, Input);
		case 6:
			return CPU.IXR.setregister(2, Input);
		case 7:
			return CPU.IXR.setregister(3, Input);
		case 8:
			return CPU.PC.setPCaddress(Input);
		case 9:
			return CPU.MAR.setMemaddress(Input);
		case 10:
			return CPU.MBR.setData(Input);
		}
		return false;
	}
	
	// This function has the ability to return each component's value based on the GUI's order.
	public int get_number(int index) {
		switch (index) {
		case 1: 
			return CPU.GPRs.getregister(0);
		case 2:
			return CPU.GPRs.getregister(1);
		case 3:
			return CPU.GPRs.getregister(2);
		case 4:
			return CPU.GPRs.getregister(3);
		case 5:
			return CPU.IXR.getregister(1);
		case 6:
			return CPU.IXR.getregister(2);
		case 7:
			return CPU.IXR.getregister(3);
		case 8:
			return CPU.PC.getPCaddress();
		case 9:
			return CPU.MAR.getMemaddress();
		case 10:
			return CPU.MBR.getData();
		case 11:
			return CPU.IR.getinstruction();
		case 12:
			return CPU.MFR.getFault();
		case 13:
			return CPU.device.keyboard;
		case 14:
			return CPU.device.printer;
		}
		return 0;
	}
	

	public int program1input(String inputstring) {
		int input = Integer.parseInt(inputstring);
		CPU.device.keyboard = input;
		pro1inputcnt++;
		if (pro1inputcnt == 20) {
			return 0;
		}
		else {
			return 1;
		}
	}
	
	// Function to load the Program-1 into memory
	public void loadprogram1() {
		pro1inputcnt = 0;
		CPU.load_program1();
	}
	
	// Function returns the number used to compare with the 20 numbers
	public int pro1target() {
		return CPU.cache.readCache(122 + 8);
	}
	
	// Function to print the 20 numbers together
	public int pro1_20numbers(int i) {
		return CPU.cache.readCache(101 + 8 + i);
	}
	
	public int printer() {
		return CPU.device.printer;
	}
}

package gui;

import java.util.HashMap;

public class Const {
    public static final HashMap<String, String> OPCODE = new HashMap<String, String>();
    static {
        OPCODE.put("000000", "HLT");
        OPCODE.put("011110", "TRAP");
        OPCODE.put("000001", "LDR");
        OPCODE.put("000010", "STR");
        OPCODE.put("000011", "LDA");
        OPCODE.put("101001", "LDX");
        OPCODE.put("101010", "STX");
        OPCODE.put("111101", "IN");
        OPCODE.put("111110", "OUT");
        OPCODE.put("001010", "JZ");
        OPCODE.put("001011", "JNE");
        OPCODE.put("001100", "JCC");
        OPCODE.put("001101", "JMA");
        OPCODE.put("001110", "JSR");
        OPCODE.put("001111", "RFS");
        OPCODE.put("010000", "SOB");
        OPCODE.put("010001", "JGE");
        OPCODE.put("011111", "SRC");
        OPCODE.put("100000", "RRC");
        OPCODE.put("000100", "AMR");
        OPCODE.put("000101", "SMR");
        OPCODE.put("010111", "AND");
        OPCODE.put("011000", "ORR");
        OPCODE.put("011001", "NOT");
        OPCODE.put("000110", "AIR");
        OPCODE.put("000111", "SIR");
        OPCODE.put("010100", "MLT");
        OPCODE.put("010101", "DVD");
        OPCODE.put("010110", "TRR");
        OPCODE.put("111111", "CHK");
        OPCODE.put("100001", "FADD");
        OPCODE.put("100010", "FSUB");
        OPCODE.put("100011", "VADD");
        OPCODE.put("100100", "VSUB");
        OPCODE.put("100101", "CNVRT");
        OPCODE.put("110010", "LDFR");
        OPCODE.put("110011", "STFR");
    }

    public static final HashMap<String, String> OpCodeToBinary = new HashMap<String, String>();
    static {
        OpCodeToBinary.put("HLT", "000000");
        OpCodeToBinary.put("TRAP","011000");
        OpCodeToBinary.put("LDR", "000001");
        OpCodeToBinary.put("STR", "000010");
        OpCodeToBinary.put("LDA", "000011");
        OpCodeToBinary.put("LDX", "100001");
        OpCodeToBinary.put("STX", "100010");
        OpCodeToBinary.put("IN", "110001");
        OpCodeToBinary.put("OUT", "110010");
        OpCodeToBinary.put("JZ", "001000");
        OpCodeToBinary.put("JNE", "001001");
        OpCodeToBinary.put("JCC", "001010");
        OpCodeToBinary.put("JMA", "001011");
        OpCodeToBinary.put("JSR", "001100");
        OpCodeToBinary.put("RFS", "001101");
        OpCodeToBinary.put("SOB", "001110");
        OpCodeToBinary.put("JGE", "001111");
        OpCodeToBinary.put("SRC", "011001");
        OpCodeToBinary.put("RRC", "011010");
        OpCodeToBinary.put("AMR", "000100");
        OpCodeToBinary.put("SMR", "000101");
        OpCodeToBinary.put("AND", "010011");
        OpCodeToBinary.put("ORR", "010100");
        OpCodeToBinary.put("NOT", "010101");
        OpCodeToBinary.put("AIR", "000110");
        OpCodeToBinary.put("SIR", "000111");
        OpCodeToBinary.put("MLT", "010000");
        OpCodeToBinary.put("DVD", "010001");
        OpCodeToBinary.put("TRR", "010010");
        OpCodeToBinary.put("CHK", "110011");
        OpCodeToBinary.put("FADD", "011011");
        OpCodeToBinary.put("FSUB", "011100");
        OpCodeToBinary.put("VADD", "011101");
        OpCodeToBinary.put("VSUB", "011110");
        OpCodeToBinary.put("CNVRT", "011111");
        OpCodeToBinary.put("LDFR", "101000");
        OpCodeToBinary.put("STFR","101001");
    }
}

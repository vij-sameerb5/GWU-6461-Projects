package conversion;

// convert decimal to binary
public class ConvertDecToBin {
public static String convertDecToBin(int number) {
	return Integer.toBinaryString(number);
}
}

package components;

// ALU not complete yet

public class ALU {
	private int Y = 0;
	private int Z = 0;
	public condition_code CC = new condition_code();
	
	
}

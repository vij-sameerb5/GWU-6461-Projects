package gui;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import components.PC;
import components.interact;
import conversion.ConvertBinToDec;

import javax.swing.JLabel;
import java.awt.Color;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JToggleButton;
import javax.swing.JDesktopPane;

public class PanelView extends JFrame {

	private JPanel contentPane;
	private JTextField GPR_0;
	private JTextField GPR_1;
	private JTextField GPR_2;
	private JTextField GPR_3;
	private JTextField IXR_1;
	private JTextField IXR_2;
	private JTextField IXR_3;
	private JTextField PC;
	private JTextField MAR;
	private JTextField MBR;
	private JTextField IR;
	private JTextField MFR;
	private JTextField textPriv;
	private JTextField textField;
	private JTextField textField_1;
	private JTextField textField_2;
	private JTextField textField_3;
	private JTextField textField_4;
	private JTextField textField_5;
	private JTextField textField_6;
	private JTextField textField_7;
	private JTextField textField_8;
	private JTextField textField_9;
	private JTextField textField_10;
	private JTextField textField_11;
	private JTextField textField_12;
	private JTextField textField_13;
	private JTextField textField_14;
	private JTextField textField_15;
	private JTextField textHalt;
	private JTextField textRun;
	
	private interact cpu;		
	
	String OPR_bit0;
	String OPR_bit1;
	String OPR_bit2;
	String OPR_bit3;
	String OPR_bit4;
	String OPR_bit5;
	String GPR_bit1;
	String GPR_bit0;
	String IXR_bit1;
	String IXR_bit0;
	String i;
	String ip_add_4_bit;
	String ip_add_3_bit;
	String ip_add_2_bit;
	String ip_add_1_bit;
	String ip_add_0_bit;
	String instruction, operation, address, gpr, ixr;

	/**
	 * Main method to Launch the GUI
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					PanelView frame = new PanelView();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * All the components on GUI
	 */
	public PanelView() {
		//Set the main Frame
		setTitle("CSCI 6461 | TEAM 2 ");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 620, 450);
		contentPane = new JPanel();
		contentPane.setBackground(Color.lightGray);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		//For GUI interacts with CPU components
		cpu = new interact();
		
		
		//Labels for GPR, IXR
		JLabel lbGPR_0 = new JLabel("GPR 0");
		lbGPR_0.setBounds(20, 20, 41, 16);
		contentPane.add(lbGPR_0);
		
		JLabel lbGPR_1 = new JLabel("GPR 1");
		lbGPR_1.setBounds(20, 40, 41, 16);
		contentPane.add(lbGPR_1);
		
		JLabel lbGPR_2 = new JLabel("GPR 2");
		lbGPR_2.setBounds(20, 60, 41, 16);
		contentPane.add(lbGPR_2);
		
		JLabel lbGPR_3 = new JLabel("GPR 3");
		lbGPR_3.setBounds(20, 80, 41, 16);
		contentPane.add(lbGPR_3);
		
		JLabel lbIXR_1 = new JLabel("IXR 1");
		lbIXR_1.setBounds(20, 120, 41, 16);
		contentPane.add(lbIXR_1);
		
		JLabel lbIXR_2 = new JLabel("IXR 2");
		lbIXR_2.setBounds(20, 140, 41, 16);
		contentPane.add(lbIXR_2);
		
		JLabel lbIXR_3 = new JLabel("IXR 3");
		lbIXR_3.setBounds(20, 160, 41, 16);
		contentPane.add(lbIXR_3);
		
		//Set text box to show data of GPR0  
		GPR_0 = new JTextField();
		
		//When any key is typed by the user
		GPR_0.addKeyListener(new KeyAdapter() {
			@Override
			public void keyTyped(KeyEvent e) {
				char c = e.getKeyChar();
				if(!Character.isDigit(c)) {
					e.consume();
				}
			}
			//
			@Override
			public void keyPressed(KeyEvent e) {
				String input = GPR_0.getText();
				int length = input.length();
				char c = e.getKeyChar();
				if(e.getKeyChar()>= '0' && e.getKeyChar()<='1') {
					if(length<16) {
						GPR_0.setEditable(true);
					} else {
						GPR_0.setEditable(false);
					} 
				} else {
					if(e.getExtendedKeyCode()==KeyEvent.VK_BACK_SPACE || e.getExtendedKeyCode()==KeyEvent.VK_DELETE) {
						GPR_0.setEditable(true);
					} else {
						GPR_0.setEditable(false);
					}
					}
			}
		});
		GPR_0.setBounds(70, 20, 160, 16);
		contentPane.add(GPR_0);
		GPR_0.setColumns(10);
		
		//Set text box to show data of GPR1
		GPR_1 = new JTextField();
		GPR_1.addKeyListener(new KeyAdapter() {
			@Override
			public void keyTyped(KeyEvent e) {
				char c = e.getKeyChar();
				if(!Character.isDigit(c)) {
					e.consume();
					}
				}
			@Override
			public void keyPressed(KeyEvent e) {
				String input = GPR_1.getText();
				int length = input.length();
				char c = e.getKeyChar();
				if(e.getKeyChar()>= '0' && e.getKeyChar()<='1') {
					if(length<16) {
						GPR_1.setEditable(true);
					} else {
						GPR_1.setEditable(false);
					} 
				} else {
					if(e.getExtendedKeyCode()==KeyEvent.VK_BACK_SPACE || e.getExtendedKeyCode()==KeyEvent.VK_DELETE) {
						GPR_1.setEditable(true);
					} else {
						GPR_1.setEditable(false);
					}
					}
			}
		});
		GPR_1.setColumns(10);
		GPR_1.setBounds(70, 40, 160, 16);
		contentPane.add(GPR_1);
		
		//Set text box to show data of GPR2
		GPR_2 = new JTextField();
		GPR_2.addKeyListener(new KeyAdapter() {
			@Override
			public void keyTyped(KeyEvent e) {
				char c = e.getKeyChar();
				if(!Character.isDigit(c)) {
					e.consume();
					}
			}
			@Override
			public void keyPressed(KeyEvent e) {
				String input = GPR_2.getText();
				int length = input.length();
				char c = e.getKeyChar();
				if(e.getKeyChar()>= '0' && e.getKeyChar()<='1') {
					if(length<16) {
						GPR_2.setEditable(true);
					} else {
						GPR_2.setEditable(false);
					} 
				} else {
					if(e.getExtendedKeyCode()==KeyEvent.VK_BACK_SPACE || e.getExtendedKeyCode()==KeyEvent.VK_DELETE) {
						GPR_2.setEditable(true);
					} else {
						GPR_2.setEditable(false);
					}
					}
			}
		});
		GPR_2.setColumns(10);
		GPR_2.setBounds(70, 60, 160, 16);
		contentPane.add(GPR_2);
		
		//Set text box to show data of GPR3
		GPR_3 = new JTextField();
		GPR_3.addKeyListener(new KeyAdapter() {
			@Override
			public void keyTyped(KeyEvent e) {
				char c = e.getKeyChar();
				if(!Character.isDigit(c)) {
					e.consume();
					}
			}
			@Override
			public void keyPressed(KeyEvent e) {
				String input = GPR_3.getText();
				int length = input.length();
				char c = e.getKeyChar();
				if(e.getKeyChar()>= '0' && e.getKeyChar()<='1') {
					if(length<16) {
						GPR_3.setEditable(true);
					} else {
						GPR_3.setEditable(false);
					} 
				} else {
					if(e.getExtendedKeyCode()==KeyEvent.VK_BACK_SPACE || e.getExtendedKeyCode()==KeyEvent.VK_DELETE) {
						GPR_3.setEditable(true);
					} else {
						GPR_3.setEditable(false);
					}
					}
			}
		});
		GPR_3.setColumns(10);
		GPR_3.setBounds(70, 80, 160, 16);
		contentPane.add(GPR_3);
		
		//Set text box to show data of IXR1
		IXR_1 = new JTextField();
		IXR_1.addKeyListener(new KeyAdapter() {
			@Override
			public void keyTyped(KeyEvent e) {
				char c = e.getKeyChar();
				if(!Character.isDigit(c)) {
					e.consume();
					}
			}
			@Override
			public void keyPressed(KeyEvent e) {
				String input = IXR_1.getText();
				int length = input.length();
				char c = e.getKeyChar();
				if(e.getKeyChar()>= '0' && e.getKeyChar()<='1') {
					if(length<16) {
						IXR_1.setEditable(true);
					} else {
						IXR_1.setEditable(false);
					} 
				} else {
					if(e.getExtendedKeyCode()==KeyEvent.VK_BACK_SPACE || e.getExtendedKeyCode()==KeyEvent.VK_DELETE) {
						IXR_1.setEditable(true);
					} else {
						IXR_1.setEditable(false);
					}
					}
			}
		});
		IXR_1.setColumns(10);
		IXR_1.setBounds(70, 120, 160, 16);
		contentPane.add(IXR_1);
		
		//Set text box to show data of IXR2
		IXR_2 = new JTextField();
		IXR_2.addKeyListener(new KeyAdapter() {
			@Override
			public void keyTyped(KeyEvent e) {
				char c = e.getKeyChar();
				if(!Character.isDigit(c)) {
					e.consume();
					}
			}
			@Override
			public void keyPressed(KeyEvent e) {
				String input = IXR_2.getText();
				int length = input.length();
				char c = e.getKeyChar();
				if(e.getKeyChar()>= '0' && e.getKeyChar()<='1') {
					if(length<16) {
						IXR_2.setEditable(true);
					} else {
						IXR_2.setEditable(false);
					} 
				} else {
					if(e.getExtendedKeyCode()==KeyEvent.VK_BACK_SPACE || e.getExtendedKeyCode()==KeyEvent.VK_DELETE) {
						IXR_2.setEditable(true);
					} else {
						IXR_2.setEditable(false);
					}
					}
			}
		});
		IXR_2.setColumns(10);
		IXR_2.setBounds(70, 140, 160, 16);
		contentPane.add(IXR_2);
		
		//Set text box to show data of IXR3
		IXR_3 = new JTextField();
		IXR_3.addKeyListener(new KeyAdapter() {
			@Override
			public void keyTyped(KeyEvent e) {
				char c = e.getKeyChar();
				if(!Character.isDigit(c)) {
					e.consume();
					}
			}
			@Override
			public void keyPressed(KeyEvent e) {
				String input = IXR_3.getText();
				int length = input.length();
				char c = e.getKeyChar();
				if(e.getKeyChar()>= '0' && e.getKeyChar()<='1') {
					if(length<16) {
						IXR_3.setEditable(true);
					} else {
						IXR_3.setEditable(false);
					} 
				} else {
					if(e.getExtendedKeyCode()==KeyEvent.VK_BACK_SPACE || e.getExtendedKeyCode()==KeyEvent.VK_DELETE) {
						IXR_3.setEditable(true);
					} else {
						IXR_3.setEditable(false);
					}
					}
			}
		});
		IXR_3.setColumns(10);
		IXR_3.setBounds(70, 160, 160, 16);
		contentPane.add(IXR_3);
		
		//when LD button for GPR0 is clicked
		JButton btnGpr_0 = new JButton("LD");
		btnGpr_0.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				//Get instruction data from each text box  
				OPR_bit0 = textField.getText();
				OPR_bit1 = textField_1.getText();
				OPR_bit2 = textField_2.getText();
				OPR_bit3 = textField_3.getText();
				OPR_bit4 = textField_4.getText();
				OPR_bit5 = textField_5.getText();
				GPR_bit1 = textField_6.getText();
				GPR_bit0 = textField_7.getText();
				IXR_bit1 = textField_8.getText();
				IXR_bit0 = textField_9.getText();
				i = textField_10.getText();
				ip_add_4_bit = textField_11.getText();
				ip_add_3_bit = textField_12.getText();
				ip_add_2_bit = textField_13.getText();
				ip_add_1_bit = textField_14.getText();
				ip_add_0_bit = textField_15.getText();
				
				address =  ip_add_4_bit + ip_add_3_bit + ip_add_2_bit + ip_add_1_bit + ip_add_0_bit;
				ixr = IXR_bit1 + IXR_bit0;
				gpr = GPR_bit1 + GPR_bit0;
				operation = OPR_bit0 +  OPR_bit1 + OPR_bit2 + OPR_bit3 + OPR_bit4 + OPR_bit5;
				instruction = operation + gpr + ixr + i + address;
				
				//Call this function to load data into GPR0
				load_Gpr0();
			}
		});
		btnGpr_0.setBounds(240, 20, 50, 15);
		contentPane.add(btnGpr_0);
		
		//when LD button for GPR1 is clicked
		JButton btnGpr_1 = new JButton("LD");
		btnGpr_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				OPR_bit0 = textField.getText();
				OPR_bit1 = textField_1.getText();
				OPR_bit2 = textField_2.getText();
				OPR_bit3 = textField_3.getText();
				OPR_bit4 = textField_4.getText();
				OPR_bit5 = textField_5.getText();
				GPR_bit1 = textField_6.getText();
				GPR_bit0 = textField_7.getText();
				IXR_bit1 = textField_8.getText();
				IXR_bit0 = textField_9.getText();
				i = textField_10.getText();
				ip_add_4_bit = textField_11.getText();
				ip_add_3_bit = textField_12.getText();
				ip_add_2_bit = textField_13.getText();
				ip_add_1_bit = textField_14.getText();
				ip_add_0_bit = textField_15.getText();
				
				address =  ip_add_4_bit + ip_add_3_bit + ip_add_2_bit + ip_add_1_bit + ip_add_0_bit;
				ixr = IXR_bit1 + IXR_bit0;
				gpr = GPR_bit1 + GPR_bit0;
				operation = OPR_bit0 +  OPR_bit1 + OPR_bit2 + OPR_bit3 + OPR_bit4 + OPR_bit5;
				instruction = operation + gpr + ixr + i + address;
				
				load_Gpr1();
			}
		});
		btnGpr_1.setBounds(240, 41, 50, 15);
		contentPane.add(btnGpr_1);
		
		//when LD button for GPR1 is clicked
		JButton btnGpr_2 = new JButton("LD");
		btnGpr_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				OPR_bit0 = textField.getText();
				OPR_bit1 = textField_1.getText();
				OPR_bit2 = textField_2.getText();
				OPR_bit3 = textField_3.getText();
				OPR_bit4 = textField_4.getText();
				OPR_bit5 = textField_5.getText();
				GPR_bit1 = textField_6.getText();
				GPR_bit0 = textField_7.getText();
				IXR_bit1 = textField_8.getText();
				IXR_bit0 = textField_9.getText();
				i = textField_10.getText();
				ip_add_4_bit = textField_11.getText();
				ip_add_3_bit = textField_12.getText();
				ip_add_2_bit = textField_13.getText();
				ip_add_1_bit = textField_14.getText();
				ip_add_0_bit = textField_15.getText();
				
				address =  ip_add_4_bit + ip_add_3_bit + ip_add_2_bit + ip_add_1_bit + ip_add_0_bit;
				ixr = IXR_bit1 + IXR_bit0;
				gpr = GPR_bit1 + GPR_bit0;
				operation = OPR_bit0 +  OPR_bit1 + OPR_bit2 + OPR_bit3 + OPR_bit4 + OPR_bit5;
				instruction = operation + gpr + ixr + i + address;
				
				load_Gpr2();
			}
		});
		btnGpr_2.setBounds(240, 60, 50, 15);
		contentPane.add(btnGpr_2);
		
	    //when LD button for GPR3 is clicked
		JButton btnGpr_3 = new JButton("LD");
		btnGpr_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				OPR_bit0 = textField.getText();
				OPR_bit1 = textField_1.getText();
				OPR_bit2 = textField_2.getText();
				OPR_bit3 = textField_3.getText();
				OPR_bit4 = textField_4.getText();
				OPR_bit5 = textField_5.getText();
				GPR_bit1 = textField_6.getText();
				GPR_bit0 = textField_7.getText();
				IXR_bit1 = textField_8.getText();
				IXR_bit0 = textField_9.getText();
				i = textField_10.getText();
				ip_add_4_bit = textField_11.getText();
				ip_add_3_bit = textField_12.getText();
				ip_add_2_bit = textField_13.getText();
				ip_add_1_bit = textField_14.getText();
				ip_add_0_bit = textField_15.getText();
				
				address =  ip_add_4_bit + ip_add_3_bit + ip_add_2_bit + ip_add_1_bit + ip_add_0_bit;
				ixr = IXR_bit1 + IXR_bit0;
				gpr = GPR_bit1 + GPR_bit0;
				operation = OPR_bit0 +  OPR_bit1 + OPR_bit2 + OPR_bit3 + OPR_bit4 + OPR_bit5;
				instruction = operation + gpr + ixr + i + address;
				
				load_Gpr3();
			}
		});
		btnGpr_3.setBounds(240, 80, 50, 15);
		contentPane.add(btnGpr_3);
		
	    //when LD button for IXR1 is clicked
		JButton btnIxr_1 = new JButton("LD");
		btnIxr_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				OPR_bit0 = textField.getText();
				OPR_bit1 = textField_1.getText();
				OPR_bit2 = textField_2.getText();
				OPR_bit3 = textField_3.getText();
				OPR_bit4 = textField_4.getText();
				OPR_bit5 = textField_5.getText();
				GPR_bit1 = textField_6.getText();
				GPR_bit0 = textField_7.getText();
				IXR_bit1 = textField_8.getText();
				IXR_bit0 = textField_9.getText();
				i = textField_10.getText();
				ip_add_4_bit = textField_11.getText();
				ip_add_3_bit = textField_12.getText();
				ip_add_2_bit = textField_13.getText();
				ip_add_1_bit = textField_14.getText();
				ip_add_0_bit = textField_15.getText();
				
				address =  ip_add_4_bit + ip_add_3_bit + ip_add_2_bit + ip_add_1_bit + ip_add_0_bit;
				ixr = IXR_bit1 + IXR_bit0;
				gpr = GPR_bit1 + GPR_bit0;
				operation = OPR_bit0 +  OPR_bit1 + OPR_bit2 + OPR_bit3 + OPR_bit4 + OPR_bit5;
				instruction = operation + gpr + ixr + i + address;
				
				load_Ixr1();
			}
		});
		btnIxr_1.setBounds(240, 121, 50, 15);
		contentPane.add(btnIxr_1);
		
		//when LD button for IXR2 is clicked
		JButton btnIxr_2 = new JButton("LD");
		btnIxr_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				OPR_bit0 = textField.getText();
				OPR_bit1 = textField_1.getText();
				OPR_bit2 = textField_2.getText();
				OPR_bit3 = textField_3.getText();
				OPR_bit4 = textField_4.getText();
				OPR_bit5 = textField_5.getText();
				GPR_bit1 = textField_6.getText();
				GPR_bit0 = textField_7.getText();
				IXR_bit1 = textField_8.getText();
				IXR_bit0 = textField_9.getText();
				i = textField_10.getText();
				ip_add_4_bit = textField_11.getText();
				ip_add_3_bit = textField_12.getText();
				ip_add_2_bit = textField_13.getText();
				ip_add_1_bit = textField_14.getText();
				ip_add_0_bit = textField_15.getText();
				
				address =  ip_add_4_bit + ip_add_3_bit + ip_add_2_bit + ip_add_1_bit + ip_add_0_bit;
				ixr = IXR_bit1 + IXR_bit0;
				gpr = GPR_bit1 + GPR_bit0;
				operation = OPR_bit0 +  OPR_bit1 + OPR_bit2 + OPR_bit3 + OPR_bit4 + OPR_bit5;
				instruction = operation + gpr + ixr + i + address;
				
				load_Ixr2();
			}
		});
		btnIxr_2.setBounds(240, 141, 50, 15);
		contentPane.add(btnIxr_2);
		
		//when LD button for IXR3 is clicked
		JButton btnIxr_3 = new JButton("LD");
		btnIxr_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				OPR_bit0 = textField.getText();
				OPR_bit1 = textField_1.getText();
				OPR_bit2 = textField_2.getText();
				OPR_bit3 = textField_3.getText();
				OPR_bit4 = textField_4.getText();
				OPR_bit5 = textField_5.getText();
				GPR_bit1 = textField_6.getText();
				GPR_bit0 = textField_7.getText();
				IXR_bit1 = textField_8.getText();
				IXR_bit0 = textField_9.getText();
				i = textField_10.getText();
				ip_add_4_bit = textField_11.getText();
				ip_add_3_bit = textField_12.getText();
				ip_add_2_bit = textField_13.getText();
				ip_add_1_bit = textField_14.getText();
				ip_add_0_bit = textField_15.getText();
				
				address =  ip_add_4_bit + ip_add_3_bit + ip_add_2_bit + ip_add_1_bit + ip_add_0_bit;
				ixr = IXR_bit1 + IXR_bit0;
				gpr = GPR_bit1 + GPR_bit0;
				operation = OPR_bit0 +  OPR_bit1 + OPR_bit2 + OPR_bit3 + OPR_bit4 + OPR_bit5;
				instruction = operation + gpr + ixr + i + address;
				
				load_Ixr3();
			}
		});
		btnIxr_3.setBounds(240, 161, 50, 15);
		contentPane.add(btnIxr_3);
		
		//Labels for PC, MAR, MBR, IR, MFR, Privileged
		JLabel lblPC = new JLabel("PC");
		lblPC.setBounds(335, 20, 25, 16);
		contentPane.add(lblPC);
		
		JLabel lblMAR = new JLabel("MAR");
		lblMAR.setBounds(335, 40, 30, 16);
		contentPane.add(lblMAR);
		
		JLabel lblMBR = new JLabel("MBR");
		lblMBR.setBounds(335, 61, 30, 15);
		contentPane.add(lblMBR);
		
		JLabel lblIR = new JLabel("IR");
		lblIR.setBounds(335, 80, 25, 16);
		contentPane.add(lblIR);
		
		JLabel lblMFR = new JLabel("MFR");
		lblMFR.setBounds(443, 101, 30, 16);
		contentPane.add(lblMFR);
		
		JLabel lblPriv = new JLabel("Privileged");
		lblPriv.setBounds(407, 120, 66, 16);
		contentPane.add(lblPriv);
		
		//Set a text box to show data of PC
		PC = new JTextField();	
		PC.setColumns(10);
		PC.setBounds(415, 20, 120, 16);
		contentPane.add(PC);
		
		//Set a text box to show data of MAR
		MAR = new JTextField();
		MAR.addKeyListener(new KeyAdapter() {
			@Override
			public void keyTyped(KeyEvent e) {
				char c = e.getKeyChar();
				if(!Character.isDigit(c)) {
					e.consume();
					}
			}
			@Override
			public void keyPressed(KeyEvent e) {
				String input = MAR.getText();
				int length = input.length();
				char c = e.getKeyChar();
				if(e.getKeyChar()>= '0' && e.getKeyChar()<='1') {
					if(length<12) {
						MAR.setEditable(true);
					} else {
						MAR.setEditable(false);
					} 
				} else {
					if(e.getExtendedKeyCode()==KeyEvent.VK_BACK_SPACE || e.getExtendedKeyCode()==KeyEvent.VK_DELETE) {
						MAR.setEditable(true);
					} else {
						MAR.setEditable(false);
					}
					}
			}
		});
		MAR.setColumns(10);
		MAR.setBounds(415, 40, 120, 16);
		contentPane.add(MAR);
		
		//Set a text box to show data of MBR
		MBR = new JTextField();
		MBR.addKeyListener(new KeyAdapter() {
			@Override
			public void keyTyped(KeyEvent e) {
				char c = e.getKeyChar();
				if(!Character.isDigit(c)) {
					e.consume();
					}
			}
			@Override
			public void keyPressed(KeyEvent e) {
				String input = MBR.getText();
				int length = input.length();
				char c = e.getKeyChar();
				if(e.getKeyChar()>= '0' && e.getKeyChar()<='1') {
					if(length<16) {
						MBR.setEditable(true);
					} else {
						MBR.setEditable(false);
					} 
				} else {
					if(e.getExtendedKeyCode()==KeyEvent.VK_BACK_SPACE || e.getExtendedKeyCode()==KeyEvent.VK_DELETE) {
						MBR.setEditable(true);
					} else {
						MBR.setEditable(false);
					}
					}
			}
		});
		MBR.setColumns(10);
		MBR.setBounds(377, 60, 160, 16);
		contentPane.add(MBR);
		
		//Set a text box to show data of IR
		IR = new JTextField();
		IR.addKeyListener(new KeyAdapter() {
			@Override
			public void keyTyped(KeyEvent e) {
				char c = e.getKeyChar();
				if(!Character.isDigit(c)) {
					e.consume();
					}
			}
		});
		IR.setColumns(10);
		IR.setBounds(375, 80, 160, 16);
		contentPane.add(IR);
		
		//Set a text box to show data of MFR
		MFR = new JTextField();
		MFR.addKeyListener(new KeyAdapter() {
			@Override
			public void keyTyped(KeyEvent e) {
				char c = e.getKeyChar();
				if(!Character.isDigit(c)) {
					e.consume();
					}
			}
		});
		MFR.setColumns(10);
		MFR.setBounds(485, 101, 50, 16);
		contentPane.add(MFR);
		
		//Set a text box to show data of Privileged
		textPriv = new JTextField();
		textPriv.addKeyListener(new KeyAdapter() {
			@Override
			public void keyTyped(KeyEvent e) {
				char c = e.getKeyChar();
				if(!Character.isDigit(c)) {
					e.consume();
					}
			}
		});
		textPriv.setColumns(10);
		textPriv.setBounds(515, 120, 20, 16);
		contentPane.add(textPriv);
		
		//when LD button for PC is clicked
		JButton btnPC = new JButton("LD");
		btnPC.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				OPR_bit0 = textField.getText();
				OPR_bit1 = textField_1.getText();
				OPR_bit2 = textField_2.getText();
				OPR_bit3 = textField_3.getText();
				OPR_bit4 = textField_4.getText();
				OPR_bit5 = textField_5.getText();
				GPR_bit1 = textField_6.getText();
				GPR_bit0 = textField_7.getText();
				IXR_bit1 = textField_8.getText();
				IXR_bit0 = textField_9.getText();
				i = textField_10.getText();
				ip_add_4_bit = textField_11.getText();
				ip_add_3_bit = textField_12.getText();
				ip_add_2_bit = textField_13.getText();
				ip_add_1_bit = textField_14.getText();
				ip_add_0_bit = textField_15.getText();
				
				address =  ip_add_4_bit + ip_add_3_bit + ip_add_2_bit + ip_add_1_bit + ip_add_0_bit;
				ixr = IXR_bit1 + IXR_bit0;
				gpr = GPR_bit1 + GPR_bit0;
				operation = OPR_bit0 +  OPR_bit1 + OPR_bit2 + OPR_bit3 + OPR_bit4 + OPR_bit5;
				instruction = operation + gpr + ixr + i + address;
				
				load_PC();
			}
		});
		btnPC.setBounds(545, 20, 50, 15);
		contentPane.add(btnPC);
		
		//when LD button for MAR is clicked
		JButton btnMAR = new JButton("LD");
		btnMAR.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				OPR_bit0 = textField.getText();
				OPR_bit1 = textField_1.getText();
				OPR_bit2 = textField_2.getText();
				OPR_bit3 = textField_3.getText();
				OPR_bit4 = textField_4.getText();
				OPR_bit5 = textField_5.getText();
				GPR_bit1 = textField_6.getText();
				GPR_bit0 = textField_7.getText();
				IXR_bit1 = textField_8.getText();
				IXR_bit0 = textField_9.getText();
				i = textField_10.getText();
				ip_add_4_bit = textField_11.getText();
				ip_add_3_bit = textField_12.getText();
				ip_add_2_bit = textField_13.getText();
				ip_add_1_bit = textField_14.getText();
				ip_add_0_bit = textField_15.getText();
				
				address =  ip_add_4_bit + ip_add_3_bit + ip_add_2_bit + ip_add_1_bit + ip_add_0_bit;
				ixr = IXR_bit1 + IXR_bit0;
				gpr = GPR_bit1 + GPR_bit0;
				operation = OPR_bit0 +  OPR_bit1 + OPR_bit2 + OPR_bit3 + OPR_bit4 + OPR_bit5;
				instruction = operation + gpr + ixr + i + address;
				
				load_MAR();
			}
		});
		btnMAR.setBounds(545, 40, 50, 15);
		contentPane.add(btnMAR);
		
		//when LD button for MBR is clicked
		JButton btnMBR = new JButton("LD");
		btnMBR.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				OPR_bit0 = textField.getText();
				OPR_bit1 = textField_1.getText();
				OPR_bit2 = textField_2.getText();
				OPR_bit3 = textField_3.getText();
				OPR_bit4 = textField_4.getText();
				OPR_bit5 = textField_5.getText();
				GPR_bit1 = textField_6.getText();
				GPR_bit0 = textField_7.getText();
				IXR_bit1 = textField_8.getText();
				IXR_bit0 = textField_9.getText();
				i = textField_10.getText();
				ip_add_4_bit = textField_11.getText();
				ip_add_3_bit = textField_12.getText();
				ip_add_2_bit = textField_13.getText();
				ip_add_1_bit = textField_14.getText();
				ip_add_0_bit = textField_15.getText();
				
				address =  ip_add_4_bit + ip_add_3_bit + ip_add_2_bit + ip_add_1_bit + ip_add_0_bit;
				ixr = IXR_bit1 + IXR_bit0;
				gpr = GPR_bit1 + GPR_bit0;
				operation = OPR_bit0 +  OPR_bit1 + OPR_bit2 + OPR_bit3 + OPR_bit4 + OPR_bit5;
				instruction = operation + gpr + ixr + i + address;
				
				load_MBR();
			}
		});
		btnMBR.setBounds(545, 60, 50, 15);
		contentPane.add(btnMBR);
		
		
		//Labels for Operation, GPR, IXR, I, Address
		JLabel lblNewLabel = new JLabel("Operation");
		lblNewLabel.setBounds(79, 250, 66, 16);
		contentPane.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("GPR");
		lblNewLabel_1.setBounds(235, 250, 30, 16);
		contentPane.add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("IXR");
		lblNewLabel_2.setBounds(310, 250, 25, 16);
		contentPane.add(lblNewLabel_2);
		
		JLabel lblNewLabel_3 = new JLabel("I");
		lblNewLabel_3.setBounds(380, 250, 9, 16);
		contentPane.add(lblNewLabel_3);
		
		JLabel lblNewLabel_4 = new JLabel("Address");
		lblNewLabel_4.setBounds(460, 250, 65, 16);
		contentPane.add(lblNewLabel_4); 
		
		//when Load button is clicked
		JButton btnLoad = new JButton("Load");
		btnLoad.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				OPR_bit0 = textField.getText();
				OPR_bit1 = textField_1.getText();
				OPR_bit2 = textField_2.getText();
				OPR_bit3 = textField_3.getText();
				OPR_bit4 = textField_4.getText();
				OPR_bit5 = textField_5.getText();
				GPR_bit1 = textField_6.getText();
				GPR_bit0 = textField_7.getText();
				IXR_bit1 = textField_8.getText();
				IXR_bit0 = textField_9.getText();
				i = textField_10.getText();
				ip_add_4_bit = textField_11.getText();
				ip_add_3_bit = textField_12.getText();
				ip_add_2_bit = textField_13.getText();
				ip_add_1_bit = textField_14.getText();
				ip_add_0_bit = textField_15.getText();
				
				address =  ip_add_4_bit + ip_add_3_bit + ip_add_2_bit + ip_add_1_bit + ip_add_0_bit;
				ixr = IXR_bit1 + IXR_bit0;
				gpr = GPR_bit1 + GPR_bit0;
				operation = OPR_bit0 +  OPR_bit1 + OPR_bit2 + OPR_bit3 + OPR_bit4 + OPR_bit5;
				instruction = operation + gpr + ixr + i + address;
				
				load();
				
				
			}
		});
		btnLoad.setBounds(377, 320, 75, 30);
		contentPane.add(btnLoad);
		
		//when Store button is clicked
		JButton btnStore = new JButton("Store");
		btnStore.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				OPR_bit0 = textField.getText();
				OPR_bit1 = textField_1.getText();
				OPR_bit2 = textField_2.getText();
				OPR_bit3 = textField_3.getText();
				OPR_bit4 = textField_4.getText();
				OPR_bit5 = textField_5.getText();
				GPR_bit1 = textField_6.getText();
				GPR_bit0 = textField_7.getText();
				IXR_bit1 = textField_8.getText();
				IXR_bit0 = textField_9.getText();
				i = textField_10.getText();
				ip_add_4_bit = textField_11.getText();
				ip_add_3_bit = textField_12.getText();
				ip_add_2_bit = textField_13.getText();
				ip_add_1_bit = textField_14.getText();
				ip_add_0_bit = textField_15.getText();
				
				address =  ip_add_4_bit + ip_add_3_bit + ip_add_2_bit + ip_add_1_bit + ip_add_0_bit;
				ixr = IXR_bit1 + IXR_bit0;
				gpr = GPR_bit1 + GPR_bit0;
				operation = OPR_bit0 +  OPR_bit1 + OPR_bit2 + OPR_bit3 + OPR_bit4 + OPR_bit5;
				instruction = operation + gpr + ixr + i + address;
				
				store();
			}
		});
		btnStore.setBounds(377, 365, 75, 30);
		contentPane.add(btnStore);
		
		//when IPL button is clicked
		JButton btnNewButton_6 = new JButton("IPL");
		btnNewButton_6.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				IPL();
			}
		});
		btnNewButton_6.setBounds(470, 320, 65, 30);
		contentPane.add(btnNewButton_6);
		
		//when SS button is clicked
		JButton btnNewButton_7 = new JButton("SS");
		btnNewButton_7.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				SS();
			}
		});
		btnNewButton_7.setBounds(310, 320, 50, 45);
		contentPane.add(btnNewButton_7);
		
		//Text box for operation bit0
		textField = new JTextField();
		textField.addKeyListener(new KeyAdapter() {
			@Override
			public void keyPressed(KeyEvent e) {
				String input = textField.getText();
				int length = input.length();
				char c = e.getKeyChar();
				if(e.getKeyChar()>= '0' && e.getKeyChar()<='1') {
					if(length<1) {
						textField.setEditable(true);
					} else {
						textField.setEditable(false);
					} 
				} else {
					if(e.getExtendedKeyCode()==KeyEvent.VK_BACK_SPACE || e.getExtendedKeyCode()==KeyEvent.VK_DELETE) {
						textField.setEditable(true);
					} else {
						textField.setEditable(false);
					}
					}
			}
		});
		textField.setBounds(22, 215, 25, 26);
		contentPane.add(textField);
		textField.setColumns(10);
		
		
		//Text box for operation bit1
		textField_1 = new JTextField();
		textField_1.addKeyListener(new KeyAdapter() {
			@Override
			public void keyPressed(KeyEvent e) {
				String input = textField_1.getText();
				int length = input.length();
				char c = e.getKeyChar();
				if(e.getKeyChar()>= '0' && e.getKeyChar()<='1') {
					if(length<1) {
						textField_1.setEditable(true);
					} else {
						textField_1.setEditable(false);
					} 
				} else {
					if(e.getExtendedKeyCode()==KeyEvent.VK_BACK_SPACE || e.getExtendedKeyCode()==KeyEvent.VK_DELETE) {
						textField_1.setEditable(true);
					} else {
						textField_1.setEditable(false);
					}
					}
			}
		});
		textField_1.setColumns(10);
		textField_1.setBounds(52, 215, 25, 26);
		contentPane.add(textField_1);
		
		//Text box for operation bit2
		textField_2 = new JTextField();
		textField_2.addKeyListener(new KeyAdapter() {
			@Override
			public void keyPressed(KeyEvent e) {
				String input = textField_2.getText();
				int length = input.length();
				char c = e.getKeyChar();
				if(e.getKeyChar()>= '0' && e.getKeyChar()<='1') {
					if(length<1) {
						textField_2.setEditable(true);
					} else {
						textField_2.setEditable(false);
					} 
				} else {
					if(e.getExtendedKeyCode()==KeyEvent.VK_BACK_SPACE || e.getExtendedKeyCode()==KeyEvent.VK_DELETE) {
						textField_2.setEditable(true);
					} else {
						textField_2.setEditable(false);
					}
					}
			}
		});
		textField_2.setColumns(10);
		textField_2.setBounds(82, 215, 25, 26);
		contentPane.add(textField_2);
		
		//Text box for operation bit3
		textField_3 = new JTextField();
		textField_3.addKeyListener(new KeyAdapter() {
			@Override
			public void keyPressed(KeyEvent e) {
				String input = textField_3.getText();
				int length = input.length();
				char c = e.getKeyChar();
				if(e.getKeyChar()>= '0' && e.getKeyChar()<='1') {
					if(length<1) {
						textField_3.setEditable(true);
					} else {
						textField_3.setEditable(false);
					} 
				} else {
					if(e.getExtendedKeyCode()==KeyEvent.VK_BACK_SPACE || e.getExtendedKeyCode()==KeyEvent.VK_DELETE) {
						textField_3.setEditable(true);
					} else {
						textField_3.setEditable(false);
					}
					}
			}
		});
		textField_3.setColumns(10);
		textField_3.setBounds(112, 215, 25, 26);
		contentPane.add(textField_3);
		
		//Text box for operation bit4
		textField_4 = new JTextField();
		textField_4.addKeyListener(new KeyAdapter() {
			@Override
			public void keyPressed(KeyEvent e) {
				String input = textField_4.getText();
				int length = input.length();
				char c = e.getKeyChar();
				if(e.getKeyChar()>= '0' && e.getKeyChar()<='1') {
					if(length<1) {
						textField_4.setEditable(true);
					} else {
						textField_4.setEditable(false);
					} 
				} else {
					if(e.getExtendedKeyCode()==KeyEvent.VK_BACK_SPACE || e.getExtendedKeyCode()==KeyEvent.VK_DELETE) {
						textField_4.setEditable(true);
					} else {
						textField_4.setEditable(false);
					}
					}
			}
		});
		textField_4.setColumns(10);
		textField_4.setBounds(142, 215, 25, 26);
		contentPane.add(textField_4);

		
		//Text box for operation bit5
		textField_5 = new JTextField();
		textField_5.addKeyListener(new KeyAdapter() {
			@Override
			public void keyPressed(KeyEvent e) {
				String input = textField_5.getText();
				int length = input.length();
				char c = e.getKeyChar();
				if(e.getKeyChar()>= '0' && e.getKeyChar()<='1') {
					if(length<1) {
						textField_5.setEditable(true);
					} else {
						textField_5.setEditable(false);
					} 
				} else {
					if(e.getExtendedKeyCode()==KeyEvent.VK_BACK_SPACE || e.getExtendedKeyCode()==KeyEvent.VK_DELETE) {
						textField_5.setEditable(true);
					} else {
						textField_5.setEditable(false);
					}
					}
			}
		});
		textField_5.setColumns(10);
		textField_5.setBounds(172, 215, 25, 26);
		contentPane.add(textField_5);
		
		//Text box for GPR bit1
		textField_6 = new JTextField();
		textField_6.addKeyListener(new KeyAdapter() {
		@Override
		public void keyPressed(KeyEvent e) {
			String input = textField_6.getText();
			int length = input.length();
			char c = e.getKeyChar();
			if(e.getKeyChar()>= '0' && e.getKeyChar()<='1') {
				if(length<1) {
					textField_6.setEditable(true);
				} else {
					textField_6.setEditable(false);
				} 
			} else {
				if(e.getExtendedKeyCode()==KeyEvent.VK_BACK_SPACE || e.getExtendedKeyCode()==KeyEvent.VK_DELETE) {
					textField_6.setEditable(true);
				} else {
					textField_6.setEditable(false);
				}
				}
		}
	});
		textField_6.setColumns(10);
		textField_6.setBounds(218, 215, 25, 26);
		contentPane.add(textField_6);
		
		//Text box for GPR bit0
		textField_7 = new JTextField();
		textField_7.addKeyListener(new KeyAdapter() {
			@Override
			public void keyPressed(KeyEvent e) {
				String input = textField_7.getText();
				int length = input.length();
				char c = e.getKeyChar();
				if(e.getKeyChar()>= '0' && e.getKeyChar()<='1') {
					if(length<1) {
						textField_7.setEditable(true);
					} else {
						textField_7.setEditable(false);
					} 
				} else {
					if(e.getExtendedKeyCode()==KeyEvent.VK_BACK_SPACE || e.getExtendedKeyCode()==KeyEvent.VK_DELETE) {
						textField_7.setEditable(true);
					} else {
						textField_7.setEditable(false);
					}
					}
			}
		});
		textField_7.setColumns(10);
		textField_7.setBounds(248, 215, 25, 26);
		contentPane.add(textField_7);
		
		//Text box for IXR bit1
		textField_8 = new JTextField();
		textField_8.addKeyListener(new KeyAdapter() {
			@Override
			public void keyPressed(KeyEvent e) {
				String input = textField_8.getText();
				int length = input.length();
				char c = e.getKeyChar();
				if(e.getKeyChar()>= '0' && e.getKeyChar()<='1') {
					if(length<1) {
						textField_8.setEditable(true);
					} else {
						textField_8.setEditable(false);
					} 
				} else {
					if(e.getExtendedKeyCode()==KeyEvent.VK_BACK_SPACE || e.getExtendedKeyCode()==KeyEvent.VK_DELETE) {
						textField_8.setEditable(true);
					} else {
						textField_8.setEditable(false);
					}
					}
			}
		});
		textField_8.setColumns(10);
		textField_8.setBounds(292, 215, 25, 26);
		contentPane.add(textField_8);
		
		//Text box for IXR bit0
		textField_9 = new JTextField();
		textField_9.addKeyListener(new KeyAdapter() {
			@Override
			public void keyPressed(KeyEvent e) {
				String input = textField_9.getText();
				int length = input.length();
				char c = e.getKeyChar();
				if(e.getKeyChar()>= '0' && e.getKeyChar()<='1') {
					if(length<1) {
						textField_9.setEditable(true);
					} else {
						textField_9.setEditable(false);
					} 
				} else {
					if(e.getExtendedKeyCode()==KeyEvent.VK_BACK_SPACE || e.getExtendedKeyCode()==KeyEvent.VK_DELETE) {
						textField_9.setEditable(true);
					} else {
						textField_9.setEditable(false);
					}
					}
			}
		});
		textField_9.setColumns(10);
		textField_9.setBounds(322, 215, 25, 26);
		contentPane.add(textField_9);
		
		//Text box for I
		textField_10 = new JTextField();
		textField_10.addKeyListener(new KeyAdapter() {
			@Override
			public void keyPressed(KeyEvent e) {
				String input = textField_10.getText();
				int length = input.length();
				char c = e.getKeyChar();
				if(e.getKeyChar()>= '0' && e.getKeyChar()<='1') {
					if(length<1) {
						textField_10.setEditable(true);
					} else {
						textField_10.setEditable(false);
					} 
				} else {
					if(e.getExtendedKeyCode()==KeyEvent.VK_BACK_SPACE || e.getExtendedKeyCode()==KeyEvent.VK_DELETE) {
						textField_10.setEditable(true);
					} else {
						textField_10.setEditable(false);
					}
					}
			}
		});
		textField_10.setColumns(10);
		textField_10.setBounds(367, 215, 25, 26);
		contentPane.add(textField_10);
		
		//Text box for address bit4
		textField_11 = new JTextField();
		textField_11.addKeyListener(new KeyAdapter() {
			@Override
			public void keyPressed(KeyEvent e) {
				String input = textField_11.getText();
				int length = input.length();
				char c = e.getKeyChar();
				if(e.getKeyChar()>= '0' && e.getKeyChar()<='1') {
					if(length<1) {
						textField_11.setEditable(true);
					} else {
						textField_11.setEditable(false);
					} 
				} else {
					if(e.getExtendedKeyCode()==KeyEvent.VK_BACK_SPACE || e.getExtendedKeyCode()==KeyEvent.VK_DELETE) {
						textField_11.setEditable(true);
					} else {
						textField_11.setEditable(false);
					}
					}
			}
		});
		textField_11.setColumns(10);
		textField_11.setBounds(412, 215, 25, 26);
		contentPane.add(textField_11);
		
		//Text box for address bit3
		textField_12 = new JTextField();
		textField_12.addKeyListener(new KeyAdapter() {
			@Override
			public void keyPressed(KeyEvent e) {
				String input = textField_12.getText();
				int length = input.length();
				char c = e.getKeyChar();
				if(e.getKeyChar()>= '0' && e.getKeyChar()<='1') {
					if(length<1) {
						textField_12.setEditable(true);
					} else {
						textField_12.setEditable(false);
					} 
				} else {
					if(e.getExtendedKeyCode()==KeyEvent.VK_BACK_SPACE || e.getExtendedKeyCode()==KeyEvent.VK_DELETE) {
						textField_12.setEditable(true);
					} else {
						textField_12.setEditable(false);
					}
					}
			}
		});
		textField_12.setColumns(10);
		textField_12.setBounds(442, 215, 25, 26);
		contentPane.add(textField_12);
		
		//Text box for address bit2
		textField_13 = new JTextField();
		textField_13.addKeyListener(new KeyAdapter() {
			@Override
			public void keyPressed(KeyEvent e) {
				String input = textField_13.getText();
				int length = input.length();
				char c = e.getKeyChar();
				if(e.getKeyChar()>= '0' && e.getKeyChar()<='1') {
					if(length<1) {
						textField_13.setEditable(true);
					} else {
						textField_13.setEditable(false);
					} 
				} else {
					if(e.getExtendedKeyCode()==KeyEvent.VK_BACK_SPACE || e.getExtendedKeyCode()==KeyEvent.VK_DELETE) {
						textField_13.setEditable(true);
					} else {
						textField_13.setEditable(false);
					}
					}
			}
		});
		textField_13.setColumns(10);
		textField_13.setBounds(472, 215, 25, 26);
		contentPane.add(textField_13);
		
		//Text box for address bit1
		textField_14 = new JTextField();
		textField_14.addKeyListener(new KeyAdapter() {
			@Override
			public void keyPressed(KeyEvent e) {
				String input = textField_14.getText();
				int length = input.length();
				char c = e.getKeyChar();
				if(e.getKeyChar()>= '0' && e.getKeyChar()<='1') {
					if(length<1) {
						textField_14.setEditable(true);
					} else {
						textField_14.setEditable(false);
					} 
				} else {
					if(e.getExtendedKeyCode()==KeyEvent.VK_BACK_SPACE || e.getExtendedKeyCode()==KeyEvent.VK_DELETE) {
						textField_14.setEditable(true);
					} else {
						textField_14.setEditable(false);
					}
					}
			}
		});
		textField_14.setColumns(10);
		textField_14.setBounds(502, 215, 25, 26);
		contentPane.add(textField_14);
		
		//Text box for address bit0
		textField_15 = new JTextField();
		textField_15.addKeyListener(new KeyAdapter() {
			@Override
			public void keyPressed(KeyEvent e) {
				String input = textField_15.getText();
				int length = input.length();
				char c = e.getKeyChar();
				if(e.getKeyChar()>= '0' && e.getKeyChar()<='1') {
					if(length<1) {
						textField_15.setEditable(true);
					} else {
						textField_15.setEditable(false);
					} 
				} else {
					if(e.getExtendedKeyCode()==KeyEvent.VK_BACK_SPACE || e.getExtendedKeyCode()==KeyEvent.VK_DELETE) {
						textField_15.setEditable(true);
					} else {
						textField_15.setEditable(false);
					}
					}
			}
		});
		textField_15.setColumns(10);
		textField_15.setBounds(532, 215, 25, 26);
		contentPane.add(textField_15);
		
		//Labels for Halt, Run
		JLabel lblNewLabel_5 = new JLabel("Halt");
		lblNewLabel_5.setBounds(210, 325, 30, 16);
		contentPane.add(lblNewLabel_5);
		
		JLabel lblNewLabel_6 = new JLabel("Run");
		lblNewLabel_6.setBounds(210, 354, 35, 16);
		contentPane.add(lblNewLabel_6);
		
		//Show if program is halted
		textHalt = new JTextField();
		textHalt.setBackground(Color.WHITE);
		textHalt.setBounds(245, 320, 25, 26);
		contentPane.add(textHalt);
		textHalt.setColumns(10);
		
		//Show if program is running
		textRun = new JTextField();
		textRun.setColumns(10);
		textRun.setBackground(Color.GREEN);
		textRun.setBounds(245, 349, 25, 26);
		contentPane.add(textRun);
		
	}
	
	// get the current status of CPU and display it after each click
	public void display() {
		GPR_0.setText(Integer.toBinaryString(cpu.get_number(1)));
        GPR_1.setText(Integer.toBinaryString(cpu.get_number(2)));
        GPR_2.setText(Integer.toBinaryString(cpu.get_number(3)));
        GPR_3.setText(Integer.toBinaryString(cpu.get_number(4)));
        IXR_1.setText(Integer.toBinaryString(cpu.get_number(5)));
        IXR_2.setText(Integer.toBinaryString(cpu.get_number(6)));
        IXR_3.setText(Integer.toBinaryString(cpu.get_number(7)));
        PC.setText(Integer.toBinaryString(cpu.get_number(8)));
        MAR.setText(Integer.toBinaryString(cpu.get_number(9)));
        MBR.setText(Integer.toBinaryString(cpu.get_number(10)));
        IR.setText(Integer.toBinaryString(cpu.get_number(11)));
        MFR.setText(Integer.toBinaryString(cpu.get_number(12)));
	}
	
	// give the input of load instruction to the CPU and execute and check whether something went wrong or not. Halt if something went wrong.
	public void load() {
        int halt = cpu.Load_button(instruction);
        display();
        if (halt == 1) {
        	textHalt.setBackground(Color.RED);
        	textRun.setBackground(Color.WHITE);
        }
	}
	
	// give the input of store instruction to the CPU and execute and check whether something went wrong or not. Halt if something went wrong.
	public void store() {
        int halt = cpu.Store_button(instruction);
        display();
        if (halt == 1) {
        	textHalt.setBackground(Color.RED);
        	textRun.setBackground(Color.WHITE);
        }
	}
	
	// call the initial function of CPU which restart the machine
	public void IPL() {
		int halt = cpu.IPL_button();
		display();
        textHalt.setBackground(Color.WHITE);
       	textRun.setBackground(Color.GREEN);
	}
	
	// call the run single step function including all the operations of executing an instruction
	public void SS() {
		int halt = cpu.SS_button();
		display();
		if (halt == 1) {
        	textHalt.setBackground(Color.RED);
        	textRun.setBackground(Color.WHITE);
        }
	}
	
	// load the input to the Gpr0
	public void load_Gpr0() {
		cpu.LD_button(instruction, 1);
		display();
	}
	
	// load the input to the Gpr1
	public void load_Gpr1() {
		cpu.LD_button(instruction, 2);
		display();
	}
	
	// load the input to the Gpr2
	public void load_Gpr2() {
		cpu.LD_button(instruction, 3);
		display();
	}
	
	// load the input to the Gpr3
	public void load_Gpr3() {
		cpu.LD_button(instruction, 4);
		display();
	}
	
	// load the input to the Ixr1
	public void load_Ixr1() {
		cpu.LD_button(instruction, 5);
		display();
	}
	
	// load the input to the Ixr2
	public void load_Ixr2() {
		cpu.LD_button(instruction, 6);
		display();
	}
	
	// load the input to the Ixr3
	public void load_Ixr3() {
		cpu.LD_button(instruction, 7);
		display();
	}
	
	// load the input to the PC
	public void load_PC() {
		cpu.LD_button(instruction, 8);
		display();
	}
	
	// load the input to the MAR
	public void load_MAR() {
		cpu.LD_button(instruction, 9);
		display();
	}
	
	// load the input to the MBR
	public void load_MBR() {
		cpu.LD_button(instruction, 10);
		display();
	}
}
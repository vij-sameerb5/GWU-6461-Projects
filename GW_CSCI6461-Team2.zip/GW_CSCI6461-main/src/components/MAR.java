package components;

public class MAR{
	//Initializes the MAR
	private int Memaddress = 0;

	public MAR(){
	}
	
	// "Retrieves and provides the current address in the MAR."
	public int getMemaddress(){
		return Memaddress;
	}

	//"Retrieves the new address, checks for its suitability, and then assigns it."
	public boolean setMemaddress(int newaddress){
		if (newaddress < Math.pow(2,12) && newaddress >= 0){
			Memaddress = newaddress;
			return true;
		}
		else
			return false;
	}
}
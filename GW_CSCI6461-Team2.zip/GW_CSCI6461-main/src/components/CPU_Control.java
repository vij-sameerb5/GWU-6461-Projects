package components;

// "This class manages all instances of the components and has the capability to decode instructions and carry out their execution."
import java.io.*;
import conversion.*;

public class CPU_Control{
	// All the components including Memory
	public PC PC = new PC();
	public General_Purpose_Registers GPRs = new General_Purpose_Registers();
	public Instruction_Register IR = new Instruction_Register();
	public Index_Registers IXR = new Index_Registers();
	public MAR MAR = new MAR();
	public MBR MBR = new MBR();
	public MFR MFR = new MFR();
	public Memory Mem = new Memory();
	// Machine fault status 
	private int mfindex = 0;
	// Halt or Not
	public int halt = 0;

	public CPU_Control(){
	}
// "This configures the starting components of the machine, either for the initial setup or for a restart."
	public void initial(){
		PC = new PC(0);
		GPRs = new General_Purpose_Registers();
		IR = new Instruction_Register();
		IXR = new Index_Registers(0, 100, 1000);
		MAR = new MAR();
		MBR = new MBR();
		MFR.resetMFR();
		Mem = new Memory(2048,7);
		Mem.CPUwrite(1, 6);
		Mem.CPUwrite(6, 0b0000000000000000);
		
		//Reset halt
		halt = 0; 
		
		// Read IPL.txt and load it to the memory
		try {
			String pathname = "./IPL.txt";
			File IPL = new File(pathname);
			InputStreamReader reader = new InputStreamReader(new FileInputStream(IPL));
			BufferedReader br = new BufferedReader(reader);
			String line = "";
			while (line != null) {
				line  = br.readLine();
				if (line == null) break;
				String[] loadtoMem = line.split(" ");
				mfindex = Mem.writeMem(ConvertHexToDec.convertHexToDec(loadtoMem[0])+7, ConvertHexToDec.convertHexToDec(loadtoMem[1]));
				checkaddress();
			}
			br.close();
		}	catch (Exception e) {
			e.printStackTrace();
		}
	}
	
// This function is for post-Project #1 to run a single cycle of our machine simulator.
	public void runsinglestep(){
		// If the machine halts, the CPU will not work any more
		if (halt == 1) return;
		// Set the MAR according to the PC
		MAR.setMemaddress(PC.getPCaddress());
		// PC += 1
		PC.PCPlus();
		// Get the instruction from the Memory to MBR
		mfindex = Mem.readMem(MAR.getMemaddress()+7);
		checkaddress();
		MBR.setData(Mem.readMem(MAR.getMemaddress()+7));
		// Set the instruction to IR from MBR
		IR.setinstruction(MBR.getData());
		// Decode and get the opcode and then execute instruction accordingly
		switch(IR.getopcode()){
			case 1:
				Load();
				break;
			case 2:
				Store();
				break;
			case 0:
				Halt();
				break;
			case 3:
				LDA();
				break;
			case 33:
				LDX();
				break;
			case 34:
				STX();
				break;
			default:
				MFR.setFault(2);
				halt = 1;
		}
	}
	
	public void runinstruction() {
		// if the machine halts, the CPU will not work any more
		if (halt == 1) return;
		switch(IR.getopcode()){
		case 1:
			Load();
			break;
		case 2:
			Store();
			break;
		case 0:
			Halt();
			break;
		case 3:
			LDA();
			break;
		case 33:
			LDX();
			break;
		case 34:
			STX();
			break;
		default:
			MFR.setFault(2);
			halt = 1;
	}
	}
	
// This acts as the load instruction
	public void Load(){
		int EA = 0;
		// Checks for an IR indirect in each register and computing the correct EA
		if (IR.getindirect() == 0) {
			if (IR.getindexregister() == 0) {
				EA = IR.getaddress();
			}
			else if (IR.getindexregister() > 0 && IR.getindexregister() < 4) {
				EA = IXR.getregister(IR.getindexregister()) + IR.getaddress();
			}
		}
		else if (IR.getindirect() == 1) {
			if (IR.getindexregister() == 0) {
				MAR.setMemaddress(IR.getaddress());
				mfindex = Mem.readMem(MAR.getMemaddress()+7);
				checkaddress();
				MBR.setData(Mem.readMem(MAR.getMemaddress()+7));
				EA = MBR.getData();
			}
			else if (IR.getindexregister() > 0 && IR.getindexregister() < 4) {
				MAR.setMemaddress(IXR.getregister(IR.getindexregister()) + IR.getaddress());
				mfindex = Mem.readMem(MAR.getMemaddress()+7);
				checkaddress();
				MBR.setData(Mem.readMem(MAR.getMemaddress()+7));
				EA = MBR.getData();
			}
		}
		// Set the correct EA to the MAR
		MAR.setMemaddress(EA);
		// Read the Memory and fetch the data to the MBR
		mfindex = Mem.readMem(MAR.getMemaddress()+7);
		checkaddress();
		MBR.setData(Mem.readMem(MAR.getMemaddress()+7));
		// Load the data in MBR to the target register
		GPRs.setregister(IR.getregister(), MBR.getData());
	}
	
// Store instruction
	public void Store(){
		int EA = 0;
		// Checks for an IR indirect in each register and computing the correct EA
		if (IR.getindirect() == 0) {
			if (IR.getindexregister() == 0) {
				EA = IR.getaddress();
			}
			else if (IR.getindexregister() > 0 && IR.getindexregister() < 4) {
				EA = IXR.getregister(IR.getindexregister()) + IR.getaddress();
			}
		}
		else if (IR.getindirect() == 1) {
			if (IR.getindexregister() == 0) {
				MAR.setMemaddress(IR.getaddress());
				mfindex = Mem.readMem(MAR.getMemaddress()+7);
				checkaddress();
				MBR.setData(Mem.readMem(MAR.getMemaddress()+7));
				EA = MBR.getData();
			}
			else if (IR.getindexregister() > 0 && IR.getindexregister() < 4) {
				MAR.setMemaddress(IXR.getregister(IR.getindexregister()) + IR.getaddress());
				mfindex = Mem.readMem(MAR.getMemaddress()+7);
				checkaddress();
				MBR.setData(Mem.readMem(MAR.getMemaddress()+7));
				EA = MBR.getData();
			}
		}
		// Set the correct EA to the MAR
		MAR.setMemaddress(EA);
		// Get the data from GPRs to MBR
		MBR.setData(GPRs.getregister(IR.getregister()));
		// Write the data in MBR to the Memory with the address of MAR
		mfindex = Mem.writeMem(MAR.getMemaddress()+7, MBR.getData());
		checkaddress();
	}
	
	// This acts as the LDA instruction
	public void LDA(){
		int EA = 0;
		// Checks for an IR indirect in each register and computing the correct EA
		if (IR.getindirect() == 0) {
			if (IR.getindexregister() == 0) {
				EA = IR.getaddress();
			}
			else if (IR.getindexregister() > 0 && IR.getindexregister() < 4) {
				EA = IXR.getregister(IR.getindexregister()) + IR.getaddress();
			}
		}
		else if (IR.getindirect() == 1) {
			if (IR.getindexregister() == 0) {
				MAR.setMemaddress(IR.getaddress());
				mfindex = Mem.readMem(MAR.getMemaddress()+7);
				checkaddress();
				MBR.setData(Mem.readMem(MAR.getMemaddress()+7));
				EA = MBR.getData();
			}
			else if (IR.getindexregister() > 0 && IR.getindexregister() < 4) {
				MAR.setMemaddress(IXR.getregister(IR.getindexregister()) + IR.getaddress());
				mfindex = Mem.readMem(MAR.getMemaddress()+7);
				checkaddress();
				MBR.setData(Mem.readMem(MAR.getMemaddress()+7));
				EA = MBR.getData();
			}
		}
		
		// Load the EA to the target register
		GPRs.setregister(IR.getregister(), EA);
	}
	

	// This acts as the LDX instruction
	public void LDX(){
		int EA = 0;
		// Checks for an IR indirect in each register and computing the correct EA
		if (IR.getindirect() == 0) {
			if (IR.getindexregister() == 0) {
				EA = IR.getaddress();
			}
			else if (IR.getindexregister() > 0 && IR.getindexregister() < 4) {
				EA = IXR.getregister(IR.getindexregister()) + IR.getaddress();
			}
		}
		else if (IR.getindirect() == 1) {
			if (IR.getindexregister() == 0) {
				MAR.setMemaddress(IR.getaddress());
				mfindex = Mem.readMem(MAR.getMemaddress()+7);
				checkaddress();
				MBR.setData(Mem.readMem(MAR.getMemaddress()+7));
				EA = MBR.getData();
			}
			else if (IR.getindexregister() > 0 && IR.getindexregister() < 4) {
				MAR.setMemaddress(IXR.getregister(IR.getindexregister()) + IR.getaddress());
				mfindex = Mem.readMem(MAR.getMemaddress()+7);
				checkaddress();
				MBR.setData(Mem.readMem(MAR.getMemaddress()+7));
				EA = MBR.getData();
			}
		}
		// set the correct EA to the MAR
		MAR.setMemaddress(EA);
		// read the Memory and fetch the data to the MBR
		mfindex = Mem.readMem(MAR.getMemaddress()+7);
		checkaddress();
		MBR.setData(Mem.readMem(MAR.getMemaddress()+7));
		// load the data in MBR to the target register
		IXR.setregister(IR.getindexregister(), MBR.getData());
	}
	
	// STX instruction
	public void STX(){
		int EA = 0;
		// checks for an IR indirect in each register and computing the correct EA
		if (IR.getindirect() == 0) {
			if (IR.getindexregister() == 0) {
				EA = IR.getaddress();
			}
			else if (IR.getindexregister() > 0 && IR.getindexregister() < 4) {
				EA = IXR.getregister(IR.getindexregister()) + IR.getaddress();
			}
		}
		else if (IR.getindirect() == 1) {
			if (IR.getindexregister() == 0) {
				MAR.setMemaddress(IR.getaddress());
				mfindex = Mem.readMem(MAR.getMemaddress()+7);
				checkaddress();
				MBR.setData(Mem.readMem(MAR.getMemaddress()+7));
				EA = MBR.getData();
			}
			else if (IR.getindexregister() > 0 && IR.getindexregister() < 4) {
				MAR.setMemaddress(IXR.getregister(IR.getindexregister()) + IR.getaddress());
				mfindex = Mem.readMem(MAR.getMemaddress()+7);
				checkaddress();
				MBR.setData(Mem.readMem(MAR.getMemaddress()+7));
				EA = MBR.getData();
			}
		}
		// set the correct EA to the MAR
		MAR.setMemaddress(EA);
		// get the data from GPRs to MBR
		MBR.setData(IXR.getregister(IR.getindexregister()));
		// write the data in MBR to the Memory with the address of MAR
		mfindex = Mem.writeMem(MAR.getMemaddress()+7, MBR.getData());
		checkaddress();
	}
	
// Checks the access of memory is write or not. If not, we go to set the MFR and get solution which is halt right now
	public void checkaddress() {
		if (mfindex == -1) {
			MFR.setFault(0);
			machinefault();
		}
		else if (mfindex == -2) {
			MFR.setFault(3);
			machinefault();
		}
	}

// Deals with the machine fault
	public void machinefault() {
		if (MFR.getFault() >= 0 && MFR.getFault() < 4) {
			// find the solution's address which is 6
			MAR.setMemaddress(1);
			MBR.setData(Mem.CPUaccess(MAR.getMemaddress()));
			//get the solution instruction which is halt right now
			MAR.setMemaddress(MBR.getData());
			MBR.setData(Mem.CPUaccess(MAR.getMemaddress()));
			IR.setinstruction(MBR.getData());
			runinstruction();
		}
	}
	
	public void Halt() {
		halt = 1;
	}
}
package components;

public class MBR{
	//initializes the MBR
	private int Data = 0;

	public MBR(){
	}

	//getData returns the data in the MBR
	public int getData(){
		return Data;
	}

	public boolean setData(int newData){
		//"verifies the suitability of the data prior to assigning it to the MBR"
		if (newData < Math.pow(2,16) && newData >= 0){
			Data = newData;
			return true;
		}
		else
			return false;
	}
}